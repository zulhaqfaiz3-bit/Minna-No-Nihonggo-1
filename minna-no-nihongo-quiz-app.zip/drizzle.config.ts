import "dotenv/config";
import { defineConfig } from "drizzle-kit";

// Never embed sandbox credentials in production migration configuration.
const connectionString = process.env.DATABASE_URL_UNPOOLED?.trim() || process.env.DATABASE_URL?.trim();

export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  out: "./drizzle",
  dbCredentials: connectionString ? { url: connectionString } : undefined,
  migrations: { schema: "nihongo_migrations", table: "__drizzle_migrations" },
  strict: true,
});
