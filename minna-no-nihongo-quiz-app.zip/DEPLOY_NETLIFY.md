# Opsi A — Deploy Nihongo ke Netlify dengan seluruh fitur

Proyek ini memakai **Next.js App Router + PostgreSQL + Drizzle**. Opsi A yang disiapkan adalah deploy melalui repository Git, menggunakan adapter **OpenNext otomatis Netlify**. API, progres, bookmark, target harian, furigana, dan 175 audio tetap tersedia.

> Ini bukan static export. Jangan mengunggah folder `.next` lewat Netlify Drop, jangan mengubah publish directory ke `public`/`out`, dan jangan menambahkan redirect `/* /index.html 200`. Cara-cara tersebut tidak menjalankan API database.

## 1. Siapkan database produksi

Rekomendasi: buat proyek PostgreSQL baru di [Neon](https://neon.com). Database Supabase atau PostgreSQL hosted lain juga dapat dipakai.

- Gunakan **database kosong yang dikhususkan untuk aplikasi ini** pada deploy pertama.
- Salin connection string **pooled** dari provider, termasuk parameter SSL yang diberikan provider. Jangan menghapus parameter SSL dan jangan menonaktifkan verifikasi sertifikat.
- Jika provider menyediakan URL **direct/unpooled**, simpan juga URL itu untuk migrasi.
- Jangan gunakan `localhost`, `127.0.0.1`, atau connection string sandbox. Netlify tidak dapat mengakses PostgreSQL pada komputer/sandbox tersebut.
- Untuk Supabase dengan jaringan serverless IPv4, gunakan connection string pooler yang sesuai dokumentasi provider.

Penyimpanan progres menggunakan PostgreSQL di luar instance Functions, sehingga tidak hilang ketika serverless function dimulai ulang.

## 2. Push source code ke repository Git

Push proyek ke GitHub, GitLab, atau Bitbucket. Pastikan file/folder berikut ikut masuk:

- `netlify.toml`, `.nvmrc`, `next.config.ts`
- `package.json` dan **`package-lock.json`**
- `drizzle.config.ts` serta folder **`drizzle/`** beserta SQL dan metadata migrasinya
- folder `src/`, `scripts/`, dan **seluruh `public/`** termasuk 175 berkas MP3

Jangan commit `.env`, `node_modules`, `.next`, atau `.netlify`. `.gitignore` sudah disiapkan. Jika `.env` pernah terlanjur di-commit, hapus dari tracking dan rotasi kredensial; menambah `.gitignore` saja tidak menghapus file yang sudah terlacak.

## 3. Import repository ke Netlify

Di Netlify pilih **Add new project → Import an existing project**, lalu pilih repository tersebut.

Konfigurasi dibaca otomatis dari `netlify.toml`:

| Pengaturan | Nilai |
| --- | --- |
| Base directory | root proyek, biarkan kosong jika repository berisi proyek ini saja |
| Build command | `node scripts/netlify-build.mjs` |
| Publish directory | `.next` |
| Node.js | `22` |
| Next.js adapter | OpenNext otomatis, tidak perlu memasang atau pin plugin legacy |

Jika ada pengaturan lama di dashboard, samakan dengan tabel di atas. Hapus `NETLIFY_NEXT_PLUGIN_SKIP=true` bila sebelumnya digunakan untuk static export.

## 4. Set environment variables sebelum deploy

Buka **Project configuration → Environment variables**. Tambahkan nilai rahasia melalui dashboard, bukan di `netlify.toml` atau repository.

| Variabel | Wajib? | Scope | Isi |
| --- | --- | --- | --- |
| `DATABASE_URL` | Ya | **Builds + Functions** | Connection string PostgreSQL hosted, sebaiknya pooled |
| `DATABASE_URL_UNPOOLED` | Opsional | **Builds** | URL direct untuk migrasi; jika kosong, migrasi memakai `DATABASE_URL` |
| `APP_ORIGIN` | Opsional | **Functions** | Origin publik yang tepat, misalnya domain kustom HTTPS tanpa path; membantu bila proxy/domain menghasilkan origin berbeda |
| `RUN_DATABASE_MIGRATIONS` | Opsional | **Builds** | `true` untuk menjalankan migrasi, `false` jika database dimigrasikan secara terpisah |

**Jangan** gunakan awalan `NEXT_PUBLIC_` pada URL database: itu akan mengekspos kredensial ke browser. Pada plan tanpa pilihan scope terpisah, gunakan scope all agar Builds dan Functions sama-sama mendapatkan nilainya.

Setelah mengubah environment variables, **redeploy**. Variabel yang hanya ditulis di `netlify.toml` tidak otomatis tersedia pada Functions saat runtime.

## 5. Deploy

Jalankan deploy produksi. Skrip build akan:

1. Menolak URL database yang belum diisi atau masih menunjuk ke localhost.
2. Memeriksa materi, 275 soal, ilustrasi, dan seluruh 175 audio.
3. Pada konteks **production**, menerapkan migrasi Drizzle secara default. Migrasi yang sudah selesai tidak diulang; advisory lock mencegah deploy bersamaan menerapkan migrasi pada waktu yang sama.
4. Menjalankan Next.js type generation, TypeScript, dan production build.
5. Menyerahkan pemaketan API/SSR ke adapter OpenNext otomatis Netlify.

Python dan layanan pembuat audio **tidak diperlukan saat deploy**. Berkas MP3 sudah disiapkan di `public/audio`.

### Deploy Previews dan branch deploys

Migrasi otomatis **tidak dijalankan** pada Deploy Preview atau branch deploy, kecuali `RUN_DATABASE_MIGRATIONS=true` ditetapkan.

Gunakan database/branch terpisah beserta `DATABASE_URL` dan `DATABASE_URL_UNPOOLED` yang sesuai untuk setiap konteks. Bila preview memakai database kosong, aktifkan migrasi hanya setelah URL tersebut diarahkan ke database preview. Jangan memakai kredensial produksi pada pull request yang tidak dipercaya.

## 6. Verifikasi setelah deploy

- Buka `/api/health`. Respons sukses berisi `ok: true` dan `database: ready`.
- Buka satu bab dan putar audio. Permintaan MP3 dapat menghasilkan HTTP `200` atau `206`; keduanya valid.
- Selesaikan kuis, buat bookmark, lalu refresh. Nilai dan bookmark harus tetap tersedia.
- Progres masih diidentifikasi menggunakan cookie per browser; tidak otomatis berpindah antarperangkat.

## Migrasi manual dan pengembangan berikutnya

Untuk migrasi manual, set URL database pada environment lokal yang aman, lalu jalankan:

```sh
npm ci
npm exec -- tsx scripts/migrate-db.ts
```

Setiap perubahan schema berikutnya:

```sh
npx drizzle-kit generate --name=nama_perubahan
```

Review dan commit SQL beserta metadata migrasinya sebelum deploy. Build **tidak memakai `drizzle-kit push --force`**, sehingga tidak menyetujui penghapusan data secara otomatis.

### Jika database sebelumnya sudah dibuat dengan `drizzle-kit push`

Migrasi awal ditujukan untuk database baru. Jangan memaksakannya pada database berisi tabel yang sama dan jangan menghapus tabel/progres yang sudah ada. Pada deploy pertama, gunakan database produksi baru. Jika harus memakai database lama, set `RUN_DATABASE_MIGRATIONS=false` dan lakukan baseline migrasi setelah schema diverifikasi; backup database terlebih dahulu.

## Troubleshooting

| Gejala | Pemeriksaan |
| --- | --- |
| Build mengatakan `DATABASE_URL belum disetel` | Tambahkan variabel dengan scope Builds dan Functions; redeploy. |
| URL lokal ditolak | Pakai PostgreSQL hosted; database sandbox tidak tersedia dari Netlify. |
| `/api/health` memberi `DATABASE_NOT_CONFIGURED` | Variabel tidak tersedia pada Functions atau URL tidak valid. |
| `DATABASE_SCHEMA_NOT_READY` | Migrasi belum dijalankan. Aktifkan migrasi produksi atau jalankan skrip migrasi manual. |
| `DATABASE_UNAVAILABLE` | Periksa SSL, izin, connection string/pooler, dan status provider. |
| Migrasi gagal dengan `42P07` | Tabel sudah ada tetapi belum punya riwayat migrasi; lihat bagian database lama, jangan menghapus data. |
| API POST memberi `403` di domain kustom | Set `APP_ORIGIN` ke origin HTTPS situs tersebut pada scope Functions lalu redeploy. Origin asing tetap ditolak. |
| Audio `404` | Pastikan seluruh `public/audio/` ikut di-push; jangan menjalankan generator Python di build Netlify. |
| Halaman muncul tetapi API `404` | Gunakan Git deploy + `.next` + OpenNext; hapus static export, SPA catch-all, atau konfigurasi plugin legacy. |

Dokumentasi rujukan: [Next.js on Netlify](https://docs.netlify.com/build/frameworks/framework-setup-guides/nextjs/overview/), [Environment variables Netlify](https://docs.netlify.com/build/environment-variables/overview/), [Drizzle migrations](https://orm.drizzle.team/docs/migrations).
