var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/learning/route.js")
R.c("server/chunks/[externals]_next_dist_0arv.vj._.js")
R.c("server/chunks/[root-of-the-server]__03kulev._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/[root-of-the-server]__0gpkjb5._.js")
R.c("server/chunks/[root-of-the-server]__11j~5mn._.js")
R.c("server/chunks/_next-internal_server_app_api_learning_route_actions_0vqpz2f.js")
R.m(55271)
module.exports=R.m(55271).exports
