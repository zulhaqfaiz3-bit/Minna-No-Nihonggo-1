module.exports=[78162,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_learning_route_actions_0vqpz2f.js.map