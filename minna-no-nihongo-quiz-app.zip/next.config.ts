import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  poweredByHeader: false,
  serverExternalPackages: ["pg"],
  // Keep the native Next.js output. Netlify's OpenNext adapter packages API
  // routes as Node.js functions; output: "export" would remove those APIs.
};

export default nextConfig;
