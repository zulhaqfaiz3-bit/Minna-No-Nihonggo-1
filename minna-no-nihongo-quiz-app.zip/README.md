# Nihongo

Aplikasi pendamping belajar bahasa Jepang berbahasa Indonesia dengan 25 bab, 275 soal partikel/kotoba/terjemahan/listening, furigana, 125 kosakata, dan 175 audio pelafalan orisinal.

## Deploy ke Netlify — Opsi A

Ikuti **[DEPLOY_NETLIFY.md](./DEPLOY_NETLIFY.md)**. Konfigurasi Next.js/OpenNext, Node.js 22, migrasi Drizzle, pemeriksaan audio, dan environment variables sudah disiapkan.

**Ringkas:** import repository Git ke Netlify, tambahkan `DATABASE_URL` PostgreSQL hosted dengan scope Builds + Functions, lalu deploy. Build command `node scripts/netlify-build.mjs`; publish directory `.next`.

Proyek ini fullstack, **bukan** folder HTML statis untuk drag-and-drop. Jangan mengunggah `.env` atau menggunakan database localhost di Netlify.

## Menjalankan lokal

1. Gunakan Node.js 22 dan jalankan `npm ci`.
2. Salin `.env.example` menjadi `.env` dan isi `DATABASE_URL` PostgreSQL lokal/hosted.
3. Untuk database kosong jalankan `npm exec -- tsx scripts/migrate-db.ts`.
4. Jalankan `npm run dev`.

Jika database lokal sebelumnya sudah dibuat menggunakan Drizzle push, jangan menerapkan migrasi awal lagi pada tabel yang sudah ada; lihat panduan deployment.

## Pemeriksaan

```sh
node scripts/check-assets.mjs
npx next typegen
npm exec tsc -- --noEmit --pretty false
npm run build
```

Setelah production server tersedia, jalankan `node scripts/smoke-test.mjs` untuk memeriksa alur belajar di browser. Set `APP_URL` jika alamat situs berbeda dari default localhost. Pengujian menghasilkan data profil/kuis untuk sesi browser pengujian; jangan gunakan pada database produksi pengguna.

Untuk memeriksa konfigurasi Netlify, proteksi origin, kelengkapan audio, dan migrasi pada database lokal sementara yang otomatis dihapus, jalankan `npm exec -- tsx scripts/test-netlify.ts`. Tes ini tidak membuat database pengujian pada provider produksi.

Build adapter Netlify juga dapat diperiksa tanpa deploy melalui `npm exec --yes --package=netlify-cli -- netlify build --offline --context dev`. Perintah tersebut tidak memerlukan akses akun Netlify dan tidak mengunggah situs; membutuhkan koneksi untuk mengunduh CLI/adapter bila belum tersedia di cache.

Berkas MP3 sudah tersedia di `public/audio`. Skrip Python di `scripts/` hanya alat regenerasi audio dan tidak dibutuhkan oleh Netlify.

## Materi dan privasi

Seluruh soal, contoh, dan audio dibuat orisinal sebagai pendamping independen berdasarkan cakupan topik Minna no Nihongo I, bukan salinan atau rekaman resmi buku.

Progres, bookmark, dan pengaturan disimpan di PostgreSQL, dengan cookie anonim per browser. Kredensial database hanya dibaca server; tidak memakai `NEXT_PUBLIC_DATABASE_URL`.
