import type { QuizKind } from "./learning-data";

export type AttemptSummary = {
  id: string; chapterId: number; kind: QuizKind; score: number; total: number;
  duration: number; createdAt: string;
};
export type LearningState = {
  profile: { name: string; dailyTarget: number; furigana: boolean };
  bookmarks: number[];
  completed: number[];
  attempts: AttemptSummary[];
  stats: { quizCount: number; accuracy: number; streak: number; totalMinutes: number; todayMinutes: number; todayQuestions: number };
};
export const initialLearningState: LearningState = {
  profile: { name: "Teman belajar", dailyTarget: 15, furigana: true },
  bookmarks: [], completed: [], attempts: [],
  stats: { quizCount: 0, accuracy: 0, streak: 0, totalMinutes: 0, todayMinutes: 0, todayQuestions: 0 },
};
