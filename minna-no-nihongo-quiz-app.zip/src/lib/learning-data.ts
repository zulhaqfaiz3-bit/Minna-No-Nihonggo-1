export type QuizKind = "particles" | "vocabulary" | "translation" | "listening" | "mixed";
export type Vocabulary = { jp: string; romaji: string; meaning: string };
export type Example = { jp: string; meaning: string };
export type Particle = { jp: string; answer: string; options: string[]; explanation: string };
export type Chapter = {
  id: number; title: string; japanese: string; description: string; grammar: string[];
  words: Vocabulary[]; examples: Example[]; particles: Particle[];
};
export type Question = {
  id: string; kind: QuizKind; instruction: string; jp: string; audio?: string;
  options: string[]; answer: string; explanation: string;
};

const word = (jp: string, romaji: string, meaning: string): Vocabulary => ({ jp, romaji, meaning });
const example = (jp: string, meaning: string): Example => ({ jp, meaning });
const particle = (jp: string, answer: string, options: string[], explanation: string): Particle => ({ jp, answer, options, explanation });

export const chapters: Chapter[] = [
  {
    id: 1, title: "Halo, Jepang!", japanese: "はじめまして", description: "Perkenalan diri & identitas", grammar: ["N1 は N2 です", "N1 は N2 じゃありません", "N1 の N2"],
    words: [word("私[わたし]", "watashi", "Saya"), word("学生[がくせい]", "gakusei", "Pelajar / mahasiswa"), word("先生[せんせい]", "sensei", "Guru"), word("会社員[かいしゃいん]", "kaishain", "Karyawan perusahaan"), word("日本[にほん]", "Nihon", "Jepang")],
    examples: [example("私[わたし]はインドネシア人[じん]です。", "Saya orang Indonesia."), example("アユさんは学生[がくせい]ですか。", "Apakah Ayu seorang pelajar?")],
    particles: [particle("私[わたし]（　）学生[がくせい]です。", "は", ["は", "を", "に", "で"], "は menandai topik kalimat. Watashi wa gakusei desu berarti saya seorang pelajar."), particle("私[わたし]は日本語[にほんご]（　）先生[せんせい]です。", "の", ["の", "を", "へ", "と"], "の menghubungkan kata benda: nihongo no sensei adalah guru bahasa Jepang.")],
  },
  {
    id: 2, title: "Ini, itu, yang mana?", japanese: "これはなんですか", description: "Mengenal benda di sekitar", grammar: ["これ・それ・あれ", "この N・その N・あの N", "そうです / そうじゃありません"],
    words: [word("本[ほん]", "hon", "Buku"), word("辞書[じしょ]", "jisho", "Kamus"), word("時計[とけい]", "tokei", "Jam"), word("傘[かさ]", "kasa", "Payung"), word("鍵[かぎ]", "kagi", "Kunci")],
    examples: [example("これは日本語[にほんご]の本[ほん]です。", "Ini buku bahasa Jepang."), example("その傘[かさ]は私[わたし]のです。", "Payung itu milik saya.")],
    particles: [particle("これは私[わたし]（　）本[ほん]です。", "の", ["の", "に", "で", "を"], "の menyatakan kepemilikan. Watashi no hon berarti buku milik saya."), particle("それ（　）辞書[じしょ]ですか。", "は", ["は", "へ", "と", "が"], "は memperkenalkan topik sore (benda dekat lawan bicara).")],
  },
  {
    id: 3, title: "Di mana tempatnya?", japanese: "ここはどこですか", description: "Tempat, arah & lokasi", grammar: ["ここ・そこ・あそこ", "N は 場所[ばしょ] です", "こちら・そちら・あちら"],
    words: [word("教室[きょうしつ]", "kyōshitsu", "Ruang kelas"), word("食堂[しょくどう]", "shokudō", "Kantin"), word("受付[うけつけ]", "uketsuke", "Resepsionis"), word("階段[かいだん]", "kaidan", "Tangga"), word("銀行[ぎんこう]", "ginkō", "Bank")],
    examples: [example("食堂[しょくどう]はあそこです。", "Kantin ada di sana."), example("ここは私[わたし]の教室[きょうしつ]です。", "Di sini adalah ruang kelas saya.")],
    particles: [particle("受付[うけつけ]（　）どこですか。", "は", ["は", "を", "へ", "で"], "は menandai resepsionis sebagai topik yang ditanyakan lokasinya."), particle("これは日本[にほん]（　）時計[とけい]です。", "の", ["の", "に", "へ", "が"], "の menyatakan asal: Nihon no tokei adalah jam buatan Jepang.")],
  },
  {
    id: 4, title: "Jam berapa sekarang?", japanese: "いまなんじですか", description: "Waktu & kegiatan sehari-hari", grammar: ["V ます・ません・ました", "〜から 〜まで", "時間[じかん] に V"],
    words: [word("起[お]きます", "okimasu", "Bangun tidur"), word("寝[ね]ます", "nemasu", "Tidur"), word("働[はたら]きます", "hatarakimasu", "Bekerja"), word("朝[あさ]", "asa", "Pagi"), word("毎日[まいにち]", "mainichi", "Setiap hari")],
    examples: [example("毎朝[まいあさ]六時[ろくじ]に起[お]きます。", "Saya bangun pukul enam setiap pagi."), example("九時[くじ]から五時[ごじ]まで働[はたら]きます。", "Saya bekerja dari pukul sembilan sampai pukul lima.")],
    particles: [particle("七時[しちじ]（　）起[お]きます。", "に", ["に", "を", "で", "と"], "に menandai waktu yang spesifik, seperti pukul tujuh."), particle("九時[くじ]から五時[ごじ]（　）働[はたら]きます。", "まで", ["まで", "から", "に", "を"], "から berarti dari dan まで berarti sampai. Keduanya menandai rentang waktu.")],
  },
  {
    id: 5, title: "Ayo pergi!", japanese: "どこへいきますか", description: "Perjalanan & transportasi", grammar: ["場所[ばしょ] へ 行[い]きます", "乗[の]り物[もの] で V", "人[ひと] と V"],
    words: [word("行[い]きます", "ikimasu", "Pergi"), word("来[き]ます", "kimasu", "Datang"), word("帰[かえ]ります", "kaerimasu", "Pulang"), word("電車[でんしゃ]", "densha", "Kereta"), word("友達[ともだち]", "tomodachi", "Teman")],
    examples: [example("電車[でんしゃ]で京都[きょうと]へ行[い]きます。", "Saya pergi ke Kyoto dengan kereta."), example("友達[ともだち]と学校[がっこう]へ行[い]きます。", "Saya pergi ke sekolah bersama teman.")],
    particles: [particle("日本[にほん]（　）行[い]きます。", "へ", ["へ", "を", "で", "と"], "へ menandai arah atau tujuan perjalanan dan dibaca e."), particle("電車[でんしゃ]（　）帰[かえ]ります。", "で", ["で", "に", "が", "の"], "で menandai alat transportasi yang digunakan.")],
  },
  {
    id: 6, title: "Hari yang menyenangkan", japanese: "いっしょにいきませんか", description: "Aktivitas & ajakan", grammar: ["N を V", "場所[ばしょ] で V", "V ませんか / V ましょう"],
    words: [word("食[た]べます", "tabemasu", "Makan"), word("飲[の]みます", "nomimasu", "Minum"), word("見[み]ます", "mimasu", "Melihat / menonton"), word("読[よ]みます", "yomimasu", "Membaca"), word("写真[しゃしん]", "shashin", "Foto")],
    examples: [example("食堂[しょくどう]で昼[ひる]ごはんを食[た]べます。", "Saya makan siang di kantin."), example("一緒[いっしょ]に映画[えいが]を見[み]ませんか。", "Maukah kamu menonton film bersama?")],
    particles: [particle("本[ほん]（　）読[よ]みます。", "を", ["を", "は", "に", "へ"], "を menandai objek dari tindakan membaca dan dibaca o."), particle("図書館[としょかん]（　）勉強[べんきょう]します。", "で", ["で", "に", "を", "が"], "で menunjukkan tempat berlangsungnya suatu kegiatan.")],
  },
  {
    id: 7, title: "Untukmu, dariku", japanese: "どうぞありがとう", description: "Memberi, menerima & alat", grammar: ["道具[どうぐ] で V", "人[ひと] に あげます", "人[ひと] に もらいます"],
    words: [word("切[き]ります", "kirimasu", "Memotong"), word("送[おく]ります", "okurimasu", "Mengirim"), word("花[はな]", "hana", "Bunga"), word("手紙[てがみ]", "tegami", "Surat"), word("母[はは]", "haha", "Ibu saya")],
    examples: [example("母[はは]に花[はな]をあげます。", "Saya memberikan bunga kepada ibu."), example("日本語[にほんご]で手紙[てがみ]を書[か]きます。", "Saya menulis surat dalam bahasa Jepang.")],
    particles: [particle("はさみ（　）紙[かみ]を切[き]ります。", "で", ["で", "を", "へ", "が"], "で menandai alat yang dipakai untuk melakukan tindakan."), particle("友達[ともだち]（　）プレゼントをあげます。", "に", ["に", "を", "で", "の"], "に menunjukkan penerima sesuatu pada kata kerja agemasu.")],
  },
  {
    id: 8, title: "Seperti apa?", japanese: "どんなまちですか", description: "Sifat & kesan pertama", grammar: ["い形容詞[けいようし] / な形容詞[けいようし]", "とても / あまり", "〜が、〜"],
    words: [word("大[おお]きい", "ōkii", "Besar"), word("小[ちい]さい", "chiisai", "Kecil"), word("新[あたら]しい", "atarashii", "Baru"), word("静[しず]か", "shizuka", "Tenang"), word("有名[ゆうめい]", "yūmei", "Terkenal")],
    examples: [example("京都[きょうと]はとてもきれいな町[まち]です。", "Kyoto adalah kota yang sangat indah."), example("この部屋[へや]はあまり大[おお]きくないです。", "Kamar ini tidak begitu besar.")],
    particles: [particle("この町[まち]（　）静[しず]かです。", "は", ["は", "を", "に", "で"], "は menandai kota ini sebagai topik yang dijelaskan sifatnya."), particle("この本[ほん]はおもしろいです（　）、高[たか]いです。", "が", ["が", "を", "へ", "の"], "が di antara dua kalimat dapat berarti tetapi: menarik, tetapi mahal.")],
  },
  {
    id: 9, title: "Yang aku suka", japanese: "なにがすきですか", description: "Kesukaan & kemampuan", grammar: ["N が 好[す]きです", "N が わかります", "〜から、〜"],
    words: [word("好[す]き", "suki", "Suka"), word("上手[じょうず]", "jōzu", "Mahir"), word("音楽[おんがく]", "ongaku", "Musik"), word("料理[りょうり]", "ryōri", "Masakan"), word("約束[やくそく]", "yakusoku", "Janji")],
    examples: [example("私[わたし]は日本[にほん]の音楽[おんがく]が好[す]きです。", "Saya suka musik Jepang."), example("日本語[にほんご]が少[すこ]しわかります。", "Saya sedikit mengerti bahasa Jepang.")],
    particles: [particle("私[わたし]は料理[りょうり]（　）好[す]きです。", "が", ["が", "を", "へ", "で"], "Objek kesukaan dengan suki ditandai が, bukan を."), particle("忙[いそが]しいです（　）、行[い]きません。", "から", ["から", "まで", "に", "の"], "から setelah kalimat menunjukkan alasan: karena sibuk, tidak pergi.")],
  },
  {
    id: 10, title: "Ada di mana?", japanese: "なにがありますか", description: "Keberadaan & posisi benda", grammar: ["N が あります / います", "場所[ばしょ] に N が あります", "N の 上[うえ]・下[した]・中[なか]"],
    words: [word("猫[ねこ]", "neko", "Kucing"), word("犬[いぬ]", "inu", "Anjing"), word("机[つくえ]", "tsukue", "Meja"), word("上[うえ]", "ue", "Atas"), word("公園[こうえん]", "kōen", "Taman")],
    examples: [example("机[つくえ]の上[うえ]に本[ほん]があります。", "Ada buku di atas meja."), example("公園[こうえん]に猫[ねこ]がいます。", "Ada kucing di taman.")],
    particles: [particle("部屋[へや]（　）机[つくえ]があります。", "に", ["に", "で", "を", "と"], "に menunjukkan lokasi keberadaan. で digunakan untuk lokasi kegiatan."), particle("庭[にわ]に犬[いぬ]（　）います。", "が", ["が", "を", "で", "へ"], "が menandai makhluk yang ada. Imasu dipakai untuk makhluk hidup.")],
  },
  {
    id: 11, title: "Satu, dua, tiga", japanese: "いくつありますか", description: "Jumlah, penghitung & durasi", grammar: ["ひとつ・ふたつ・みっつ", "〜人[にん]・〜枚[まい]・〜台[だい]", "期間[きかん] に 〜回[かい]"],
    words: [word("一[ひと]つ", "hitotsu", "Satu buah"), word("二人[ふたり]", "futari", "Dua orang"), word("一枚[いちまい]", "ichimai", "Satu lembar"), word("一週間[いっしゅうかん]", "isshūkan", "Satu minggu"), word("全部[ぜんぶ]", "zenbu", "Semuanya")],
    examples: [example("りんごを三[みっ]つ買[か]いました。", "Saya membeli tiga buah apel."), example("一週間[いっしゅうかん]に二回[にかい]泳[およ]ぎます。", "Saya berenang dua kali dalam seminggu.")],
    particles: [particle("みかん（　）二[ふた]つください。", "を", ["を", "が", "へ", "で"], "を menandai benda yang diminta, diikuti jumlah dan kudasai."), particle("一週間[いっしゅうかん]（　）三回[さんかい]勉強[べんきょう]します。", "に", ["に", "を", "が", "と"], "に menandai satuan periode untuk menyatakan frekuensi.")],
  },
  {
    id: 12, title: "Mana yang lebih baik?", japanese: "どちらがいいですか", description: "Perbandingan & bentuk lampau", grammar: ["〜かったです / 〜でした", "N1 は N2 より 〜", "N が いちばん 〜"],
    words: [word("暑[あつ]い", "atsui", "Panas (cuaca)"), word("寒[さむ]い", "samui", "Dingin (cuaca)"), word("近[ちか]い", "chikai", "Dekat"), word("遠[とお]い", "tōi", "Jauh"), word("速[はや]い", "hayai", "Cepat")],
    examples: [example("昨日[きのう]はとても暑[あつ]かったです。", "Kemarin sangat panas."), example("電車[でんしゃ]はバスより速[はや]いです。", "Kereta lebih cepat daripada bus.")],
    particles: [particle("日本[にほん]はインドネシア（　）寒[さむ]いです。", "より", ["より", "まで", "から", "で"], "より menandai pembanding: Jepang lebih dingin daripada Indonesia."), particle("春[はる]（　）いちばん好[す]きです。", "が", ["が", "を", "に", "で"], "が menandai hal yang paling disukai dalam pola ichiban suki.")],
  },
  {
    id: 13, title: "Aku ingin...", japanese: "なにがほしいですか", description: "Keinginan & tujuan perjalanan", grammar: ["N が 欲[ほ]しいです", "V たいです", "V に 行[い]きます"],
    words: [word("欲[ほ]しい", "hoshii", "Ingin (benda)"), word("買[か]います", "kaimasu", "Membeli"), word("遊[あそ]びます", "asobimasu", "Bermain"), word("泳[およ]ぎます", "oyogimasu", "Berenang"), word("週末[しゅうまつ]", "shūmatsu", "Akhir pekan")],
    examples: [example("新[あたら]しいカメラが欲[ほ]しいです。", "Saya ingin kamera baru."), example("京都[きょうと]へ写真[しゃしん]を撮[と]りに行[い]きます。", "Saya pergi ke Kyoto untuk mengambil foto.")],
    particles: [particle("水[みず]（　）飲[の]みたいです。", "を", ["を", "へ", "で", "の"], "を menandai objek tindakan yang ingin dilakukan: ingin minum air."), particle("公園[こうえん]へ遊[あそ]び（　）行[い]きます。", "に", ["に", "を", "で", "と"], "Bentuk masu tanpa masu + に行きます menyatakan tujuan pergi.")],
  },
  {
    id: 14, title: "Boleh minta tolong?", japanese: "ちょっとまってください", description: "Bentuk te & permintaan", grammar: ["V てください", "V ています", "V ましょうか"],
    words: [word("待[ま]ちます", "machimasu", "Menunggu"), word("持[も]ちます", "mochimasu", "Membawa / memegang"), word("開[あ]けます", "akemasu", "Membuka"), word("閉[し]めます", "shimemasu", "Menutup"), word("使[つか]います", "tsukaimasu", "Menggunakan")],
    examples: [example("窓[まど]を開[あ]けてください。", "Tolong buka jendelanya."), example("今[いま]、日本語[にほんご]を勉強[べんきょう]しています。", "Sekarang saya sedang belajar bahasa Jepang.")],
    particles: [particle("ドア（　）閉[し]めてください。", "を", ["を", "に", "が", "へ"], "を menandai objek yang ditutup dalam permintaan bentuk te."), particle("ここ（　）待[ま]ってください。", "で", ["で", "に", "を", "へ"], "で menunjukkan tempat aktivitas menunggu.")],
  },
  {
    id: 15, title: "Bolehkah aku?", japanese: "しゃしんをとってもいいですか", description: "Izin, larangan & keadaan", grammar: ["V てもいいです", "V てはいけません", "V ています（状態[じょうたい]）"],
    words: [word("住[す]みます", "sumimasu", "Tinggal"), word("知[し]ります", "shirimasu", "Mengetahui"), word("売[う]ります", "urimasu", "Menjual"), word("結婚[けっこん]します", "kekkon shimasu", "Menikah"), word("住所[じゅうしょ]", "jūsho", "Alamat")],
    examples: [example("ここで写真[しゃしん]を撮[と]ってもいいですか。", "Bolehkah saya mengambil foto di sini?"), example("私[わたし]は東京[とうきょう]に住[す]んでいます。", "Saya tinggal di Tokyo.")],
    particles: [particle("大阪[おおさか]（　）住[す]んでいます。", "に", ["に", "で", "を", "と"], "に menandai tempat tinggal dengan kata kerja sumimasu."), particle("ここ（　）たばこを吸[す]ってはいけません。", "で", ["で", "に", "へ", "が"], "で menandai tempat kegiatan yang dilarang.")],
  },
  {
    id: 16, title: "Setelah itu...", japanese: "それからなにをしますか", description: "Urutan kegiatan & penghubung", grammar: ["V て、V て、〜", "V てから、〜", "い形容詞[けいようし] くて / な形容詞[けいようし] で"],
    words: [word("乗[の]ります", "norimasu", "Naik kendaraan"), word("降[お]ります", "orimasu", "Turun kendaraan"), word("入[はい]ります", "hairimasu", "Masuk"), word("出[で]ます", "demasu", "Keluar"), word("若[わか]い", "wakai", "Muda")],
    examples: [example("朝[あさ]ごはんを食[た]べてから、学校[がっこう]へ行[い]きます。", "Setelah sarapan, saya pergi ke sekolah."), example("この部屋[へや]は明[あか]るくて、広[ひろ]いです。", "Kamar ini terang dan luas.")],
    particles: [particle("駅[えき]で電車[でんしゃ]（　）乗[の]ります。", "に", ["に", "を", "で", "と"], "に menandai kendaraan yang dinaiki dengan norimasu."), particle("バス（　）降[お]ります。", "を", ["を", "に", "で", "が"], "を menandai kendaraan yang ditinggalkan ketika turun (orimasu).")],
  },
  {
    id: 17, title: "Jangan lupa!", japanese: "わすれないでください", description: "Bentuk nai & kewajiban", grammar: ["V ないでください", "V なければなりません", "V なくてもいいです"],
    words: [word("忘[わす]れます", "wasuremasu", "Lupa"), word("失[な]くします", "nakushimasu", "Kehilangan"), word("払[はら]います", "haraimasu", "Membayar"), word("返[かえ]します", "kaeshimasu", "Mengembalikan"), word("薬[くすり]", "kusuri", "Obat")],
    examples: [example("宿題[しゅくだい]を忘[わす]れないでください。", "Tolong jangan lupa pekerjaan rumahnya."), example("毎日[まいにち]、薬[くすり]を飲[の]まなければなりません。", "Saya harus minum obat setiap hari.")],
    particles: [particle("名前[なまえ]（　）書[か]かなければなりません。", "を", ["を", "に", "が", "で"], "を menandai objek yang wajib ditulis: nama."), particle("先生[せんせい]（　）本[ほん]を返[かえ]します。", "に", ["に", "で", "へ", "の"], "に menandai penerima ketika mengembalikan sesuatu.")],
  },
  {
    id: 18, title: "Aku bisa!", japanese: "なにができますか", description: "Bentuk kamus & kemampuan", grammar: ["V 辞書形[じしょけい] ことができます", "趣味[しゅみ] は V ことです", "V 前[まえ]に、〜"],
    words: [word("弾[ひ]きます", "hikimasu", "Memainkan alat musik petik / piano"), word("歌[うた]います", "utaimasu", "Bernyanyi"), word("集[あつ]めます", "atsumemasu", "Mengumpulkan"), word("趣味[しゅみ]", "shumi", "Hobi"), word("運転[うんてん]します", "unten shimasu", "Mengemudi")],
    examples: [example("ピアノを弾[ひ]くことができます。", "Saya bisa memainkan piano."), example("寝[ね]る前[まえ]に、本[ほん]を読[よ]みます。", "Saya membaca buku sebelum tidur.")],
    particles: [particle("日本語[にほんご]を話[はな]すこと（　）できます。", "が", ["が", "を", "へ", "で"], "Pola koto ga dekimasu memakai が untuk menyatakan kemampuan."), particle("食事[しょくじ]の前[まえ]（　）、手[て]を洗[あら]います。", "に", ["に", "を", "が", "へ"], "前に menyatakan waktu sebelum kegiatan tertentu.")],
  },
  {
    id: 19, title: "Pernahkah kamu?", japanese: "いったことがありますか", description: "Pengalaman & perubahan", grammar: ["V たことがあります", "V たり、V たりします", "〜く / 〜に なります"],
    words: [word("登[のぼ]ります", "noborimasu", "Mendaki"), word("泊[と]まります", "tomarimasu", "Menginap"), word("掃除[そうじ]します", "sōji shimasu", "Membersihkan"), word("洗濯[せんたく]します", "sentaku shimasu", "Mencuci pakaian"), word("練習[れんしゅう]します", "renshū shimasu", "Berlatih")],
    examples: [example("富士山[ふじさん]に登[のぼ]ったことがあります。", "Saya pernah mendaki Gunung Fuji."), example("日曜日[にちようび]は掃除[そうじ]したり、洗濯[せんたく]したりします。", "Pada hari Minggu saya antara lain membersihkan rumah dan mencuci pakaian.")],
    particles: [particle("日本[にほん]へ行[い]ったこと（　）あります。", "が", ["が", "を", "に", "で"], "Koto ga arimasu menyatakan pengalaman yang pernah dilakukan."), particle("春[はる]になって、暖[あたた]かくなりました。天気[てんき]（　）よくなりました。", "が", ["が", "を", "へ", "で"], "が menandai subjek yang mengalami perubahan, yaitu cuaca.")],
  },
  {
    id: 20, title: "Ngobrol santai", japanese: "いっしょにいかない", description: "Bentuk biasa & bahasa informal", grammar: ["普通形[ふつうけい]（bentuk biasa）", "です → だ", "〜ない？（ajakan santai）"],
    words: [word("要[い]ります", "irimasu", "Memerlukan"), word("調[しら]べます", "shirabemasu", "Mencari informasi"), word("修理[しゅうり]します", "shūri shimasu", "Memperbaiki"), word("僕[ぼく]", "boku", "Aku (umumnya laki-laki)"), word("君[きみ]", "kimi", "Kamu (informal)")],
    examples: [example("明日[あした]、一緒[いっしょ]に映画[えいが]を見[み]ない？", "Besok, mau menonton film bersama?"), example("昨日[きのう]は忙[いそが]しかった。", "Kemarin aku sibuk.")],
    particles: [particle("明日[あした]、友達[ともだち]（　）会[あ]う。", "に", ["に", "を", "で", "の"], "に menandai orang yang ditemui dengan au. Partikel tetap sama pada bentuk biasa."), particle("このパソコン（　）修理[しゅうり]する。", "を", ["を", "が", "に", "と"], "を menandai objek yang diperbaiki, termasuk dalam percakapan informal.")],
  },
  {
    id: 21, title: "Menurutku...", japanese: "どうおもいますか", description: "Pendapat & kutipan", grammar: ["普通形[ふつうけい] と 思[おも]います", "〜と 言[い]います", "〜でしょう？"],
    words: [word("思[おも]います", "omoimasu", "Berpikir / berpendapat"), word("言[い]います", "iimasu", "Mengatakan"), word("勝[か]ちます", "kachimasu", "Menang"), word("負[ま]けます", "makemasu", "Kalah"), word("意見[いけん]", "iken", "Pendapat")],
    examples: [example("日本語[にほんご]はおもしろいと思[おも]います。", "Menurut saya bahasa Jepang menarik."), example("先生[せんせい]は「おはよう」と言[い]いました。", "Guru mengatakan, ‘Selamat pagi’.")],
    particles: [particle("明日[あした]は雨[あめ]が降[ふ]る（　）思[おも]います。", "と", ["と", "を", "で", "に"], "と menghubungkan isi pendapat dengan omoimasu."), particle("先生[せんせい]は「ありがとう」（　）言[い]いました。", "と", ["と", "を", "へ", "が"], "と menandai isi kutipan yang diucapkan.")],
  },
  {
    id: 22, title: "Orang yang...", japanese: "これはわたしがつくりました", description: "Klausa yang menerangkan benda", grammar: ["普通形[ふつうけい] ＋ N", "V ている 人[ひと]", "私[わたし] が 作[つく]った N"],
    words: [word("着[き]ます", "kimasu", "Mengenakan pakaian atas"), word("履[は]きます", "hakimasu", "Mengenakan sepatu / celana"), word("帽子[ぼうし]", "bōshi", "Topi"), word("眼鏡[めがね]", "megane", "Kacamata"), word("生[う]まれます", "umaremasu", "Lahir")],
    examples: [example("これは私[わたし]が作[つく]ったケーキです。", "Ini kue yang saya buat."), example("眼鏡[めがね]をかけている人[ひと]は先生[せんせい]です。", "Orang yang memakai kacamata itu adalah guru.")],
    particles: [particle("私[わたし]（　）買[か]った本[ほん]はおもしろいです。", "が", ["が", "は", "へ", "で"], "Subjek dalam klausa yang menerangkan kata benda biasanya memakai が."), particle("帽子[ぼうし]（　）かぶっている人[ひと]はアユさんです。", "を", ["を", "に", "が", "と"], "を menandai benda yang dikenakan, yaitu topi.")],
  },
  {
    id: 23, title: "Ketika...", japanese: "みちをわたるとき", description: "Waktu & akibat yang alami", grammar: ["〜とき、〜", "V 辞書形[じしょけい] と、〜", "N の とき"],
    words: [word("渡[わた]ります", "watarimasu", "Menyeberang"), word("曲[ま]がります", "magarimasu", "Berbelok"), word("交差点[こうさてん]", "kōsaten", "Persimpangan"), word("道[みち]", "michi", "Jalan"), word("信号[しんごう]", "shingō", "Lampu lalu lintas")],
    examples: [example("道[みち]を渡[わた]るとき、気[き]をつけてください。", "Saat menyeberang jalan, berhati-hatilah."), example("このボタンを押[お]すと、ドアが開[あ]きます。", "Jika tombol ini ditekan, pintu terbuka.")],
    particles: [particle("子供[こども]（　）とき、よく泳[およ]ぎました。", "の", ["の", "を", "へ", "で"], "Kata benda sebelum toki memakai の: kodomo no toki, saat masih anak-anak."), particle("この道[みち]をまっすぐ行[い]く（　）、駅[えき]があります。", "と", ["と", "を", "に", "が"], "と menunjukkan akibat yang secara alami atau pasti terjadi.")],
  },
  {
    id: 24, title: "Terima kasih bantuannya", japanese: "てつだってくれました", description: "Memberi & menerima bantuan", grammar: ["人[ひと] が くれます", "V てあげます", "V てもらいます / V てくれます"],
    words: [word("手伝[てつだ]います", "tetsudaimasu", "Membantu"), word("紹介[しょうかい]します", "shōkai shimasu", "Memperkenalkan"), word("説明[せつめい]します", "setsumei shimasu", "Menjelaskan"), word("案内[あんない]します", "annai shimasu", "Memandu"), word("準備[じゅんび]します", "junbi shimasu", "Mempersiapkan")],
    examples: [example("友達[ともだち]が日本語[にほんご]を教[おし]えてくれました。", "Teman mengajarkan bahasa Jepang kepada saya."), example("先生[せんせい]に漢字[かんじ]を説明[せつめい]してもらいました。", "Saya menerima penjelasan kanji dari guru.")],
    particles: [particle("友達[ともだち]（　）手伝[てつだ]ってくれました。", "が", ["が", "を", "に", "で"], "が menandai orang yang melakukan kebaikan untuk kita dengan te kuremasu."), particle("先生[せんせい]（　）日本語[にほんご]を教[おし]えてもらいました。", "に", ["に", "を", "が", "で"], "に menandai orang yang memberikan bantuan dalam pola te moraimasu.")],
  },
  {
    id: 25, title: "Kalau suatu hari...", japanese: "もしにほんへいったら", description: "Pengandaian & kondisi", grammar: ["〜たら、〜", "〜ても、〜", "もし〜 / いくら〜"],
    words: [word("考[かんが]えます", "kangaemasu", "Memikirkan"), word("着[つ]きます", "tsukimasu", "Tiba"), word("留学[りゅうがく]します", "ryūgaku shimasu", "Belajar di luar negeri"), word("機会[きかい]", "kikai", "Kesempatan"), word("頑張[がんば]ります", "ganbarimasu", "Berusaha keras")],
    examples: [example("日本[にほん]へ行[い]ったら、京都[きょうと]を見[み]たいです。", "Kalau pergi ke Jepang, saya ingin melihat Kyoto."), example("雨[あめ]が降[ふ]っても、出[で]かけます。", "Meskipun hujan, saya akan pergi keluar.")],
    particles: [particle("日本[にほん]（　）着[つ]いたら、電話[でんわ]してください。", "に", ["に", "を", "で", "と"], "に menunjukkan tempat tujuan dengan tsukimasu: tiba di Jepang."), particle("時間[じかん]（　）あったら、旅行[りょこう]したいです。", "が", ["が", "を", "に", "へ"], "が menandai sesuatu yang ada pada pola aru; tara menambahkan kondisi ‘jika’.")],
  },
];

export const quizKinds: { id: QuizKind; title: string; japanese: string; description: string; color: string }[] = [
  { id: "particles", title: "Partikel", japanese: "じょし", description: "Lengkapi kalimat dengan tepat", color: "orange" },
  { id: "vocabulary", title: "Kotoba", japanese: "ことば", description: "Tambah perbendaharaan katamu", color: "green" },
  { id: "translation", title: "Terjemahan", japanese: "ほんやく", description: "Pahami makna setiap kalimat", color: "purple" },
  { id: "listening", title: "Listening", japanese: "リスニング", description: "Biasakan telinga dengan Jepang", color: "blue" },
];

export function plainJapanese(text: string) {
  return text.replace(/\[([^\]]+)\]/g, "");
}

export function spokenJapanese(text: string) {
  return text.replace(/([一-龯々ヶ]+)\[([^\]]+)\]/g, "$2");
}

function optionsFor(answer: string, alternatives: string[], seed: number): string[] {
  const options = [answer, ...alternatives.filter((a) => a !== answer)];
  const unique = [...new Set(options)].slice(0, 4);
  const rotation = seed % unique.length;
  return [...unique.slice(rotation), ...unique.slice(0, rotation)];
}

export function getQuestions(chapterId: number, kind: QuizKind): Question[] {
  const chapter = chapters.find((c) => c.id === chapterId);
  if (!chapter) return [];
  const allExamples = chapters.flatMap((c) => c.examples);
  const particles: Question[] = chapter.particles.map((p, i) => ({
    id: `${chapterId}-p-${i}`, kind: "particles", instruction: "Pilih partikel yang tepat untuk melengkapi kalimat.",
    jp: p.jp, options: optionsFor(p.answer, p.options, chapterId + i), answer: p.answer, explanation: p.explanation,
  }));
  const vocabulary: Question[] = chapter.words.map((w, i) => ({
    id: `${chapterId}-v-${i}`, kind: "vocabulary", instruction: "Apa arti kosakata berikut dalam bahasa Indonesia?",
    jp: w.jp, options: optionsFor(w.meaning, chapter.words.map((v) => v.meaning), chapterId + i),
    answer: w.meaning, explanation: `${w.jp} (${w.romaji}) berarti ${w.meaning.toLowerCase()}.`,
  }));
  const sentenceQuestions = (type: "translation" | "listening"): Question[] => chapter.examples.map((e, i) => {
    const position = (chapterId - 1) * 2 + i;
    const alternatives = [1, 5, 9].map((offset) => allExamples[(position + offset) % allExamples.length].meaning);
    return {
      id: `${chapterId}-${type === "translation" ? "t" : "l"}-${i}`, kind: type,
      instruction: type === "listening" ? "Dengarkan audio, lalu pilih arti kalimat yang kamu dengar." : "Pilih terjemahan bahasa Indonesia yang paling tepat.",
      jp: e.jp, audio: type === "listening" ? spokenJapanese(e.jp) : undefined,
      options: optionsFor(e.meaning, alternatives, chapterId + i), answer: e.meaning,
      explanation: `${e.jp} berarti: ${e.meaning}`,
    };
  });
  const translation = sentenceQuestions("translation");
  const listening = sentenceQuestions("listening");
  if (kind === "particles") return particles;
  if (kind === "vocabulary") return vocabulary;
  if (kind === "translation") return translation;
  if (kind === "listening") return listening;
  return [...particles, ...vocabulary.slice(0, 3), ...translation, ...listening];
}

export const TOTAL_QUESTIONS = chapters.reduce((sum, chapter) => sum + chapter.particles.length + chapter.words.length + chapter.examples.length * 2, 0);
export const TOTAL_WORDS = chapters.reduce((sum, chapter) => sum + chapter.words.length, 0);
export const kindLabel = (kind: string) => kind === "mixed" ? "Kuis campuran" : quizKinds.find((k) => k.id === kind)?.title ?? kind;
