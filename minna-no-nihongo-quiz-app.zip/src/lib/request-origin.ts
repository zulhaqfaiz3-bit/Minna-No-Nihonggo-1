import type { NextRequest } from "next/server";

function canonicalOrigin(value: string | undefined | null): string | null {
  if (!value) return null;
  try {
    const url = new URL(value);
    return ["http:", "https:"].includes(url.protocol) && !url.username && !url.password ? url.origin : null;
  } catch { return null; }
}

export function isAllowedOrigin(request: NextRequest): boolean {
  const originHeader = request.headers.get("origin");
  if (!originHeader) return request.headers.get("sec-fetch-site") !== "cross-site";
  const origin = canonicalOrigin(originHeader);
  if (!origin) return false;

  const allowed = new Set<string>();
  const add = (value: string | undefined | null) => { const normalized = canonicalOrigin(value); if (normalized) allowed.add(normalized); };
  add(request.nextUrl.origin);

  // Netlify's proxy and custom domains can differ from a function's internal
  // URL. Use the request host and configured public origins, not arbitrary
  // caller-supplied X-Forwarded-Host values or broad *.netlify.app wildcards.
  const host = request.headers.get("host");
  if (host && /^[a-z0-9.[\]:-]+$/i.test(host)) {
    add(`${request.nextUrl.protocol}//${host}`);
    if (process.env.NETLIFY === "true") add(`https://${host}`);
  }
  for (const value of [process.env.APP_ORIGIN, process.env.URL, process.env.DEPLOY_PRIME_URL, process.env.DEPLOY_URL]) add(value);
  return allowed.has(origin);
}
