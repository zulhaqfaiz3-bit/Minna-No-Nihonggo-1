"use client";

import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { Pause, Play, Volume2 } from "lucide-react";
import { spokenJapanese } from "@/lib/learning-data";

const AudioContext = createContext<{ playing: string | null; speed: number; setSpeed: (speed: number) => void; play: (text: string, key: string) => void; stop: () => void } | null>(null);

export function AudioProvider({ children, onError }: { children: ReactNode; onError: (message: string) => void }) {
  const [playing, setPlaying] = useState<string | null>(null);
  const [speed, updateSpeed] = useState(1);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const requestId = useRef(0);
  const errorRef = useRef(onError);
  errorRef.current = onError;
  const stop = () => {
    requestId.current++;
    audioRef.current?.pause();
    audioRef.current = null;
    if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
    setPlaying(null);
  };
  useEffect(() => {
    if ("speechSynthesis" in window) window.speechSynthesis.getVoices();
    return () => { audioRef.current?.pause(); if ("speechSynthesis" in window) window.speechSynthesis.cancel(); };
  }, []);

  const play = async (text: string, key: string) => {
    if (playing === key) { stop(); return; }
    stop();
    const current = requestId.current;
    setPlaying(key);
    const finish = () => { if (requestId.current === current) setPlaying(null); };
    const speechFallback = async () => {
      if (!("speechSynthesis" in window)) { finish(); errorRef.current("Audio belum tersedia di browser ini. Coba Chrome, Edge, atau Safari terbaru."); return; }
      const synth = window.speechSynthesis;
      let voices = synth.getVoices();
      if (!voices.length) {
        voices = await new Promise<SpeechSynthesisVoice[]>((resolve) => {
          const done = () => { synth.removeEventListener("voiceschanged", done); resolve(synth.getVoices()); };
          synth.addEventListener("voiceschanged", done);
          setTimeout(done, 900);
        });
      }
      if (requestId.current !== current) return;
      const utterance = new SpeechSynthesisUtterance(spokenJapanese(text));
      utterance.lang = "ja-JP";
      utterance.rate = speed * 0.9;
      const japaneseVoice = voices.find((voice) => voice.lang.startsWith("ja"));
      if (japaneseVoice) utterance.voice = japaneseVoice;
      utterance.onend = finish;
      utterance.onerror = (event) => { finish(); if (event.error !== "interrupted" && event.error !== "canceled") errorRef.current("Suara Jepang belum tersedia. Aktifkan suara bahasa Jepang di pengaturan perangkat, lalu coba lagi."); };
      synth.speak(utterance);
    };
    const audio = new Audio(`/audio/${key}.mp3`);
    audio.playbackRate = speed;
    audioRef.current = audio;
    audio.onended = finish;
    try { await audio.play(); }
    catch { if (requestId.current === current) { audioRef.current = null; await speechFallback(); } }
  };
  const setSpeed = (next: number) => { updateSpeed(next); if (audioRef.current) audioRef.current.playbackRate = next; };
  return <AudioContext.Provider value={{ playing, speed, setSpeed, play, stop }}>{children}</AudioContext.Provider>;
}

export function useAudio() {
  const value = useContext(AudioContext);
  if (!value) throw new Error("AudioProvider is required");
  return value;
}

export function AudioButton({ text, audioKey, label, large = false }: { text: string; audioKey: string; label?: string; large?: boolean }) {
  const { playing, play } = useAudio();
  const active = playing === audioKey;
  return <button type="button" className={`audio-button ${large ? "large" : ""} ${active ? "playing" : ""} ${label ? "with-label" : ""}`} onClick={(event) => { event.stopPropagation(); play(text, audioKey); }} aria-label={active ? "Hentikan audio" : label ?? "Putar pelafalan Jepang"} aria-pressed={active}>
    {active ? <Pause size={large ? 23 : 17} fill="currentColor" /> : large ? <Play size={23} fill="currentColor" /> : <Volume2 size={17} />}{label && <span>{active ? "Sedang diputar" : label}</span>}
  </button>;
}

export function AudioSpeed() {
  const { speed, setSpeed } = useAudio();
  return <label className="audio-speed"><span>Kecepatan</span><select aria-label="Kecepatan audio" value={speed} onChange={(event) => setSpeed(Number(event.target.value))}><option value={0.75}>0.75×</option><option value={1}>1×</option><option value={1.25}>1.25×</option></select></label>;
}

export function Waveform({ active = false }: { active?: boolean }) {
  const heights = [10, 19, 27, 16, 34, 44, 29, 20, 37, 50, 33, 21, 14, 28, 42, 54, 38, 23, 32, 43, 29, 16, 25, 37, 21, 12, 20, 31, 17, 10];
  return <div className={`waveform ${active ? "active" : ""}`} aria-hidden="true">{heights.map((height, i) => <span key={i} style={{ height, animationDelay: `${i * 0.055}s` }} />)}</div>;
}
