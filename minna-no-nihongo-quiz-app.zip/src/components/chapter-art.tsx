import type { CSSProperties } from "react";

export function OrigamiMark({ size = 37 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 48 48" fill="none" aria-hidden="true"><path d="M4 15L23 21L39 7L31 25L44 33L27 33L22 44L18 28L4 15Z" fill="#EC7958"/><path d="M23 21L31 25L39 7L23 21Z" fill="#BF4F35"/><path d="M4 15L18 28L23 21L4 15Z" fill="#F4A284"/><path d="M18 28L27 33L22 44L18 28Z" fill="#D56142"/><path d="M31 25L27 33L44 33L31 25Z" fill="#F3A184"/></svg>;
}

export function ChapterArt({ chapterId, compact = false }: { chapterId: number; compact?: boolean }) {
  const theme = (chapterId - 1) % 5;
  const colors = ["#F7EEE3", "#EEF1E7", "#F3EDED", "#EEF1F5", "#F4F0E6"];
  return <div className={`chapter-art ${compact ? "compact" : ""}`} style={{ "--art-color": colors[theme] } as CSSProperties}>
    <svg viewBox="0 0 260 115" role="img" aria-label={`Ilustrasi bab ${chapterId}`}>
      <circle cx="197" cy="29" r="17" fill="white" opacity=".5"/><path d="M12 102C52 86 88 90 125 98C165 108 211 79 254 95" stroke="#D8CEBD" strokeWidth="1.5" fill="none" opacity=".55"/>
      {theme === 0 && <>
        <path d="M62 29H140C149 29 153 34 153 42V64C153 72 148 77 141 77H112L100 91V77H62C54 77 50 71 50 65V41C50 34 54 29 62 29Z" fill="#FFFDF9" stroke="#DFD3C2" strokeWidth="1.5"/>
        <text x="66" y="58" fontSize="15" fontFamily="sans-serif" fill="#7D6758">こんにちは</text>
        <path d="M166 46H206C212 46 215 50 215 55V72C215 78 212 81 206 81H193L199 92L183 81H166C160 81 157 77 157 72V55C157 50 160 46 166 46Z" fill="#DFA17F"/>
        <circle cx="172" cy="64" r="2.5" fill="#FFF9EC"/><circle cx="185" cy="64" r="2.5" fill="#FFF9EC"/><circle cx="198" cy="64" r="2.5" fill="#FFF9EC"/>
        <path d="M20 58L38 63L48 51L44 69L54 76L39 76L34 88L30 73L20 58Z" fill="#E78661"/>
        <path d="M228 30L232 34M228 34L232 30" stroke="#D89A75" strokeWidth="2"/>
      </>}
      {theme === 1 && <>
        <rect x="67" y="35" width="76" height="58" rx="3" fill="#8B9B81" transform="rotate(-8 67 35)"/>
        <path d="M88 34H170V93H88Z" fill="#FDFBF3" stroke="#D5D4BF" strokeWidth="1.5"/><path d="M88 34L129 40L170 34V93L129 98L88 93V34Z" fill="#FFFCF6"/><path d="M129 40V97" stroke="#D2D0B9"/>
        <path d="M97 48L119 51M97 58L119 60M97 68L119 70M139 51L162 48M139 61L162 58M139 71L162 68" stroke="#D5D7C8" strokeWidth="2" strokeLinecap="round"/>
        <rect x="181" y="27" width="8" height="65" rx="2" fill="#DCA479" transform="rotate(15 181 27)"/><path d="M164 88L166 97L171 90" fill="#6B5C4A"/>
        <circle cx="44" cy="49" r="10" fill="#D7DEC8"/><path d="M204 71C211 52 210 36 221 33C225 46 214 54 214 65" fill="#A6B198"/>
      </>}
      {theme === 2 && <>
        <path d="M65 69L106 43L139 60L181 36L207 86L166 106L126 89L87 103L65 69Z" fill="#FCF8F1" stroke="#DDCEC8" strokeWidth="1.4"/>
        <path d="M106 44L127 89M139 60L166 105" stroke="#E1D5CD" strokeWidth="1.5"/><path d="M96 79L118 70L150 82L181 69" stroke="#CF9C89" strokeWidth="2" strokeDasharray="4 4" fill="none"/>
        <path d="M158 41C158 28 167 20 177 20C188 20 196 28 196 39C196 51 177 68 177 68C177 68 158 52 158 41Z" fill="#D57C64"/><circle cx="177" cy="39" r="7" fill="#FAF0E5"/>
        <path d="M50 82V39M83 82V39M44 35H89M42 28Q68 37 91 28" stroke="#A97D66" strokeWidth="5" strokeLinecap="round"/><path d="M48 46H85" stroke="#A97D66" strokeWidth="4"/>
      </>}
      {theme === 3 && <>
        <path d="M91 86L84 101M164 86L171 101" stroke="#738594" strokeWidth="5" strokeLinecap="round"/>
        <circle cx="128" cy="60" r="40" fill="#8C9FAA"/><circle cx="128" cy="60" r="33" fill="#FFFDF6"/><circle cx="128" cy="60" r="3" fill="#6C7781"/>
        <path d="M128 60V38M128 60L145 68" stroke="#6D7B83" strokeWidth="3" strokeLinecap="round"/><path d="M128 31V35M128 85V89M100 60H104M153 60H157" stroke="#A3AAA9" strokeWidth="2"/>
        <path d="M86 30C89 15 107 13 116 23L86 30ZM141 23C150 12 169 16 172 30L141 23Z" fill="#C2947D"/>
        <path d="M194 46L200 40M195 57H204M189 34L192 27" stroke="#C2947D" strokeWidth="2" strokeLinecap="round"/>
        <path d="M53 82L60 82L60 58L73 58L73 82L80 82" stroke="#B9C5CD" strokeWidth="2" fill="none"/>
      </>}
      {theme === 4 && <>
        <circle cx="55" cy="31" r="17" fill="#EDD6AA"/><path d="M20 81L86 29L139 81Z" fill="#C7CFC2"/><path d="M67 44L86 29L102 45L91 44L84 49L77 43Z" fill="#FBFAF1"/>
        <path d="M58 72H173C194 72 210 82 217 96H58V72Z" fill="#FDFBF4" stroke="#C6C8BF" strokeWidth="1.5"/><path d="M58 92H213" stroke="#BC7A60" strokeWidth="4"/>
        <path d="M66 78H81V85H66ZM87 78H102V85H87ZM108 78H123V85H108ZM129 78H144V85H129Z" fill="#879D9C"/>
        <path d="M166 77H181L195 86H166V77Z" fill="#879D9C"/><path d="M34 103H233" stroke="#A7AA9D" strokeWidth="2"/>
        <path d="M191 39V61M180 45L190 40L202 47M181 54L191 48L203 55" stroke="#9CA88C" strokeWidth="3" strokeLinecap="round"/>
      </>}
    </svg>
  </div>;
}
