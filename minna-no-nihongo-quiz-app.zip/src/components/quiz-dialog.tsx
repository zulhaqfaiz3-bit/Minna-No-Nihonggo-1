"use client";

import { useMemo, useRef, useState } from "react";
import { ArrowRight, Check, CheckCircle2, ChevronLeft, Clock3, Headphones, LoaderCircle, RotateCcw, Sparkles, Trophy, X, XCircle } from "lucide-react";
import { getQuestions, kindLabel, type Chapter, type QuizKind } from "@/lib/learning-data";
import type { LearningState } from "@/lib/learning-state";
import { Modal } from "./modal";
import { Japanese } from "./japanese";
import { AudioButton, AudioSpeed, useAudio, Waveform } from "./audio";

type Answer = { questionId: string; answer: string };
export function QuizDialog({ chapter, kind, furigana, onClose, onSave }: { chapter: Chapter; kind: QuizKind; furigana: boolean; onClose: () => void; onSave: (body: Record<string, unknown>) => Promise<LearningState> }) {
  const questions = useMemo(() => getQuestions(chapter.id, kind), [chapter.id, kind]);
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [checked, setChecked] = useState(false);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [finished, setFinished] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState(false);
  const [review, setReview] = useState(false);
  const [exitConfirm, setExitConfirm] = useState(false);
  const started = useRef(Date.now());
  const attemptId = useRef(crypto.randomUUID());
  const payload = useRef<Record<string, unknown>>({});
  const { playing, stop } = useAudio();
  const question = questions[index];
  const correct = selected === question.answer;
  const score = questions.filter((q) => answers.find((answer) => answer.questionId === q.id)?.answer === q.answer).length;
  const accuracy = Math.round(score / questions.length * 100);
  const listeningIndex = Number(question.id.split("-").at(-1));
  const audioKey = question.kind === "vocabulary" ? `c${chapter.id}-w${listeningIndex}` : `c${chapter.id}-e${listeningIndex}`;

  const close = () => {
    if (!finished && (index > 0 || selected)) { setExitConfirm(true); return; }
    stop(); onClose();
  };
  const save = async () => {
    setSaving(true); setSaveError(false);
    try { await onSave(payload.current); } catch { setSaveError(true); } finally { setSaving(false); }
  };
  const next = async () => {
    if (!checked || selected === null) return;
    const nextAnswers = [...answers, { questionId: question.id, answer: selected }];
    setAnswers(nextAnswers); stop();
    if (index + 1 < questions.length) { setIndex(index + 1); setSelected(null); setChecked(false); }
    else {
      setFinished(true);
      payload.current = { action: "attempt", chapterId: chapter.id, kind, answers: nextAnswers, duration: Math.max(1, Math.round((Date.now() - started.current) / 1000)), attemptId: attemptId.current };
      await save();
    }
  };
  const restart = () => {
    setIndex(0); setSelected(null); setChecked(false); setAnswers([]); setFinished(false); setReview(false); setSaveError(false);
    started.current = Date.now(); attemptId.current = crypto.randomUUID(); stop();
  };

  return <Modal label={`Kuis ${kindLabel(kind)} Bab ${chapter.id}`} onClose={close} className="quiz-modal">
    <div className="modal-heading"><div className="modal-heading-copy"><span className="eyebrow orange"><Sparkles size={14} /> LATIHAN {kindLabel(kind).toUpperCase()}</span><h2>Bab {String(chapter.id).padStart(2, "0")} <span>·</span> {chapter.title}</h2></div><button className="icon-button" onClick={close} aria-label="Tutup kuis"><X size={21} /></button></div>
    {exitConfirm ? <div className="exit-confirm"><div className="empty-icon"><ChevronLeft size={30} /></div><h3>Berhenti dulu?</h3><p>Jawaban sesi ini belum disimpan. Kamu bisa melanjutkan latihan atau keluar dan mulai lagi nanti.</p><div className="button-row"><button className="button secondary" onClick={() => setExitConfirm(false)}>Lanjutkan latihan</button><button className="button primary" onClick={() => { stop(); onClose(); }}>Keluar dari kuis</button></div></div> : finished ? <>
      <div className="quiz-result"><div className="result-trophy"><Trophy size={35} /><span className="sparkle one">✦</span><span className="sparkle two">✧</span><span className="sparkle three">✦</span></div><p className="eyebrow">おつかれさまでした</p><h2>{accuracy >= 80 ? "Otsukaresama! Kerja bagus." : "Setiap latihan adalah kemajuan."}</h2><p>Kamu menjawab <strong>{score} dari {questions.length} soal</strong> dengan benar.</p><div className="result-score">{accuracy}<span>%</span></div><div className="result-details"><span><CheckCircle2 size={16} /> {score} jawaban tepat</span><span><Clock3 size={16} /> {Math.max(1, Math.ceil(Number(payload.current.duration) / 60))} menit latihan</span></div>
        <div className={`save-status ${saveError ? "error" : ""}`}>{saving ? <><LoaderCircle size={15} className="spin" /> Menyimpan progres...</> : saveError ? <><XCircle size={15} /> Belum tersimpan. <button onClick={save}>Coba lagi</button></> : <><Check size={15} /> Hasil latihan tersimpan otomatis</>}</div>
      </div>
      <div className="result-actions"><button className="button secondary" onClick={() => setReview(!review)}>{review ? "Tutup pembahasan" : "Lihat pembahasan"}</button><button className="button primary" onClick={restart} disabled={saving}><RotateCcw size={16} /> Ulangi latihan</button></div>
      {review && <div className="quiz-review">{questions.map((q, i) => { const answer = answers.find((a) => a.questionId === q.id); const isCorrect = answer?.answer === q.answer; return <div className="review-item" key={q.id}><div className="review-title"><span className={`review-index ${isCorrect ? "correct" : "incorrect"}`}>{i + 1}</span><Japanese text={q.jp} furigana={furigana} /></div><p>Jawabanmu: <strong>{answer?.answer}</strong> {isCorrect ? <Check size={15} /> : <X size={15} />}</p>{!isCorrect && <p>Jawaban tepat: <strong>{q.answer}</strong></p>}<small><Japanese text={q.explanation} furigana={furigana} mixed /></small></div>; })}</div>}
      <div className="modal-bottom single"><button className="text-button" onClick={() => { stop(); onClose(); }}>Kembali ke ruang belajar <ArrowRight size={16} /></button></div>
    </> : <>
      <div className="quiz-progress-label"><span>Soal <strong>{index + 1}</strong> dari {questions.length}</span><span>{kindLabel(question.kind)}</span></div><div className="progress-track"><span style={{ width: `${index / questions.length * 100}%` }} /></div>
      <div className="quiz-body"><p className="quiz-instruction">{question.instruction}</p>
        {question.kind === "listening" ? <div className="listening-question"><div className="listening-question-label"><Headphones size={17} /><span>Dengarkan baik-baik</span><AudioSpeed /></div><div className="listen-player"><AudioButton large text={question.jp} audioKey={audioKey} /><Waveform active={playing === audioKey} /></div><p>Kamu boleh memutar audio lebih dari sekali.</p>{checked && <Japanese text={question.jp} furigana={furigana} className="listening-transcript" />}</div> : <div className="question-japanese"><Japanese text={question.jp} furigana={furigana} />{question.kind === "vocabulary" && <AudioButton text={question.jp} audioKey={audioKey} />}</div>}
        <div className="answer-options">{question.options.map((option, i) => {
          let state = selected === option ? "selected" : "";
          if (checked && option === question.answer) state = "correct";
          else if (checked && option === selected) state = "incorrect";
          return <button key={option} className={`answer-option ${state}`} disabled={checked} onClick={() => setSelected(option)}><span className="option-letter">{String.fromCharCode(65 + i)}</span><span className={question.kind === "particles" ? "japanese" : ""}>{option}</span>{checked && option === question.answer ? <CheckCircle2 size={19} /> : checked && option === selected ? <XCircle size={19} /> : <span className="option-radio" />}</button>;
        })}</div>
        {checked && <div className={`answer-feedback ${correct ? "correct" : "incorrect"}`}>{correct ? <CheckCircle2 size={21} /> : <Sparkles size={21} />}<div><strong>{correct ? "Tepat sekali! よくできました。" : "Tidak apa-apa, kita belajar."}</strong><p><Japanese text={question.explanation} furigana={furigana} mixed /></p></div></div>}
      </div>
      <div className="modal-bottom"><span className="small-note">Pelan-pelan, kamu pasti bisa.</span>{checked ? <button className="button primary" onClick={next}>{index + 1 === questions.length ? "Lihat hasil" : "Soal berikutnya"}<ArrowRight size={16} /></button> : <button className="button primary" disabled={!selected} onClick={() => setChecked(true)}>Periksa jawaban <Check size={16} /></button>}</div>
    </>}
  </Modal>;
}
