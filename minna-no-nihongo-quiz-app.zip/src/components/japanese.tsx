"use client";

import { Fragment } from "react";

export function Japanese({ text, furigana = true, className = "", mixed = false }: { text: string; furigana?: boolean; className?: string; mixed?: boolean }) {
  const segments: { text: string; reading?: string }[] = [];
  const pattern = /([一-龯々ヶ]+)\[([^\]]+)\]/g;
  let last = 0;
  let match: RegExpExecArray | null;
  while ((match = pattern.exec(text)) !== null) {
    if (match.index > last) segments.push({ text: text.slice(last, match.index) });
    segments.push({ text: match[1], reading: match[2] });
    last = pattern.lastIndex;
  }
  if (last < text.length) segments.push({ text: text.slice(last) });
  return <span lang={mixed ? "id" : "ja"} className={`${mixed ? "mixed-japanese" : "japanese"} ${className}`}>{segments.map((segment, index) => segment.reading && furigana ? <ruby key={index} lang="ja">{segment.text}<rt>{segment.reading}</rt></ruby> : segment.reading && mixed ? <span key={index} lang="ja">{segment.text}</span> : <Fragment key={index}>{segment.text}</Fragment>)}</span>;
}
