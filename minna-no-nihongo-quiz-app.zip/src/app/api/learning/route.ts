import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { db } from "@/db";
import { databaseFailure } from "@/db/errors";
import { attempts, bookmarks, chapterProgress, learners } from "@/db/schema";
import { isAllowedOrigin } from "@/lib/request-origin";
import { chapters, getQuestions, type QuizKind } from "@/lib/learning-data";
import type { LearningState } from "@/lib/learning-state";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 30;
const COOKIE = "nihongo-learner";
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const noCache = {
  "Cache-Control": "private, no-store, max-age=0",
  "CDN-Cache-Control": "no-store",
  "Netlify-CDN-Cache-Control": "no-store",
};

async function identify(request: NextRequest) {
  const cookie = request.cookies.get(COOKIE)?.value;
  const id = cookie && uuidPattern.test(cookie) ? cookie : randomUUID();
  await db.insert(learners).values({ id }).onConflictDoNothing();
  return id;
}

const dayKey = (date: Date) => date.toLocaleDateString("en-CA", { timeZone: "Asia/Jakarta" });

async function getState(id: string): Promise<LearningState> {
  const [profiles, history, saved, completed] = await Promise.all([
    db.select().from(learners).where(eq(learners.id, id)),
    db.select().from(attempts).where(eq(attempts.learnerId, id)).orderBy(desc(attempts.createdAt)),
    db.select().from(bookmarks).where(eq(bookmarks.learnerId, id)),
    db.select().from(chapterProgress).where(eq(chapterProgress.learnerId, id)),
  ]);
  const profile = profiles[0];
  const correct = history.reduce((sum, attempt) => sum + attempt.score, 0);
  const total = history.reduce((sum, attempt) => sum + attempt.total, 0);
  const now = new Date();
  const today = history.filter((attempt) => dayKey(attempt.createdAt) === dayKey(now));
  const activeDays = new Set(history.map((attempt) => dayKey(attempt.createdAt)));
  let streak = 0;
  const start = activeDays.has(dayKey(now)) ? 0 : 1;
  for (let offset = start; offset < start + 3660; offset++) {
    if (!activeDays.has(dayKey(new Date(now.getTime() - offset * 86400000)))) break;
    streak++;
  }
  return {
    profile: { name: profile.name, dailyTarget: profile.dailyTarget, furigana: profile.furigana },
    bookmarks: saved.map((row) => row.chapterId),
    completed: completed.map((row) => row.chapterId),
    attempts: history.map((row) => ({ ...row, kind: row.kind as QuizKind, createdAt: row.createdAt.toISOString() })),
    stats: {
      quizCount: history.length, accuracy: total ? Math.round(correct / total * 100) : 0, streak,
      totalMinutes: Math.ceil(history.reduce((sum, row) => sum + row.duration, 0) / 60),
      todayMinutes: Math.ceil(today.reduce((sum, row) => sum + row.duration, 0) / 60),
      todayQuestions: today.reduce((sum, row) => sum + row.total, 0),
    },
  };
}

function reply(id: string, state: LearningState, extra: Record<string, unknown> = {}) {
  const response = NextResponse.json({ ...state, ...extra }, { headers: noCache });
  response.cookies.set(COOKIE, id, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 60 * 60 * 24 * 365, path: "/" });
  return response;
}

function unavailable(error: unknown, action: string) {
  const failure = databaseFailure(error);
  console.error(`Learning ${action}:`, failure.code);
  return NextResponse.json({ error: failure.message, code: failure.code }, { status: failure.status, headers: noCache });
}

export async function GET(request: NextRequest) {
  try {
    const id = await identify(request);
    return reply(id, await getState(id));
  } catch (error) {
    return unavailable(error, "read");
  }
}

export async function POST(request: NextRequest) {
  try {
    if (!isAllowedOrigin(request)) {
      return NextResponse.json({ error: "Permintaan tidak diizinkan." }, { status: 403, headers: noCache });
    }
    let body: Record<string, unknown>;
    try { body = await request.json(); } catch { return NextResponse.json({ error: "Data tidak valid." }, { status: 400 }); }
    if (!body || typeof body !== "object") return NextResponse.json({ error: "Data tidak valid." }, { status: 400 });
    const id = await identify(request);
    let result: Record<string, unknown> = {};

    if (body.action === "settings") {
      const name = typeof body.name === "string" ? body.name.trim() : "";
      const dailyTarget = Number(body.dailyTarget);
      if (name.length < 2 || name.length > 60 || !Number.isInteger(dailyTarget) || dailyTarget < 5 || dailyTarget > 60 || typeof body.furigana !== "boolean") {
        return NextResponse.json({ error: "Nama harus 2–60 karakter dan target 5–60 menit." }, { status: 400 });
      }
      await db.update(learners).set({ name, dailyTarget, furigana: body.furigana }).where(eq(learners.id, id));
    } else if (body.action === "bookmark" || body.action === "complete") {
      const chapterId = Number(body.chapterId);
      if (!Number.isInteger(chapterId) || !chapters.some((chapter) => chapter.id === chapterId)) {
        return NextResponse.json({ error: "Bab tidak ditemukan." }, { status: 400 });
      }
      if (body.action === "bookmark") {
        const existing = await db.select().from(bookmarks).where(and(eq(bookmarks.learnerId, id), eq(bookmarks.chapterId, chapterId)));
        if (existing.length) await db.delete(bookmarks).where(and(eq(bookmarks.learnerId, id), eq(bookmarks.chapterId, chapterId)));
        else await db.insert(bookmarks).values({ learnerId: id, chapterId }).onConflictDoNothing();
      } else {
        if (body.completed === false) await db.delete(chapterProgress).where(and(eq(chapterProgress.learnerId, id), eq(chapterProgress.chapterId, chapterId)));
        else await db.insert(chapterProgress).values({ learnerId: id, chapterId }).onConflictDoNothing();
      }
    } else if (body.action === "attempt") {
      const chapterId = Number(body.chapterId);
      const validKinds: QuizKind[] = ["particles", "vocabulary", "translation", "listening", "mixed"];
      if (typeof body.kind !== "string" || !validKinds.includes(body.kind as QuizKind)) {
        return NextResponse.json({ error: "Jenis latihan tidak valid." }, { status: 400 });
      }
      const kind = body.kind as QuizKind;
      const questions = getQuestions(chapterId, kind);
      const submitted = body.answers;
      if (!questions.length || !Array.isArray(submitted) || submitted.length !== questions.length) {
        return NextResponse.json({ error: "Jawablah semua soal sebelum menyimpan." }, { status: 400 });
      }
      const answerMap = new Map<string, string>();
      for (const answer of submitted) {
        if (!answer || typeof answer.questionId !== "string" || typeof answer.answer !== "string" || answerMap.has(answer.questionId)) {
          return NextResponse.json({ error: "Jawaban tidak valid." }, { status: 400 });
        }
        answerMap.set(answer.questionId, answer.answer);
      }
      if (questions.some((question) => !question.options.includes(answerMap.get(question.id) ?? ""))) {
        return NextResponse.json({ error: "Pilihan jawaban tidak valid." }, { status: 400 });
      }
      const score = questions.filter((question) => answerMap.get(question.id) === question.answer).length;
      const duration = Math.min(86400, Math.max(0, Math.round(Number(body.duration) || 0)));
      const attemptId = typeof body.attemptId === "string" && uuidPattern.test(body.attemptId) ? body.attemptId : randomUUID();
      await db.insert(attempts).values({
        id: attemptId, learnerId: id, chapterId, kind, score, total: questions.length, duration,
        answers: questions.map((question) => ({ questionId: question.id, answer: answerMap.get(question.id)! })),
      }).onConflictDoNothing();
      result = { result: { score, total: questions.length, accuracy: Math.round(score / questions.length * 100) } };
    } else {
      return NextResponse.json({ error: "Aksi tidak dikenal." }, { status: 400 });
    }
    return reply(id, await getState(id), result);
  } catch (error) {
    return unavailable(error, "write");
  }
}
