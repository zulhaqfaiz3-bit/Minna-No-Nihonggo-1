import { db } from "@/db";
import { databaseFailure } from "@/db/errors";
import { sql } from "drizzle-orm";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 30;

const headers = { "Cache-Control": "no-store", "Netlify-CDN-Cache-Control": "no-store" };

export async function GET() {
  try {
    const result = await db.execute(sql`
      SELECT
        to_regclass('public.nihongo_learners') IS NOT NULL AND
        to_regclass('public.nihongo_attempts') IS NOT NULL AND
        to_regclass('public.nihongo_bookmarks') IS NOT NULL AND
        to_regclass('public.nihongo_chapter_progress') IS NOT NULL AS ready
    `);
    if (result.rows[0]?.ready !== true) {
      return Response.json({ ok: false, code: "DATABASE_SCHEMA_NOT_READY", error: "Koneksi database berhasil, tetapi tabel belajar belum tersedia. Jalankan migrasi Drizzle." }, { status: 503, headers });
    }
    return Response.json({ ok: true, database: "ready" }, { headers });
  } catch (error) {
    const failure = databaseFailure(error);
    console.error("Healthcheck PostgreSQL:", failure.code);
    return Response.json({ ok: false, code: failure.code, error: failure.message }, { status: failure.status, headers });
  }
}
