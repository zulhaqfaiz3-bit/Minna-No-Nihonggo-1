import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Nihongo — Selangkah lebih dekat",
  description: "Belajar bahasa Jepang melalui 25 bab: kuis partikel, kotoba, terjemahan, listening, audio pelafalan, dan furigana. Materi pendamping independen Minna no Nihongo I.",
};
export const viewport: Viewport = { themeColor: "#FAFAF8" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="id"><head><link rel="preconnect" href="https://fonts.googleapis.com" /><link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" /><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;450;500;550;600;650;700;750&family=Plus+Jakarta+Sans:wght@400;500;550;600;650;700;750;800&family=Noto+Sans+JP:wght@400;500;600;700&display=swap" rel="stylesheet" /></head><body>{children}</body></html>;
}
