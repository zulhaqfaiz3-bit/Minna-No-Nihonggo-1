import { pgTable, uuid, varchar, integer, boolean, timestamp, jsonb, primaryKey, index } from "drizzle-orm/pg-core";

export const learners = pgTable("nihongo_learners", {
  id: uuid("id").primaryKey(),
  name: varchar("name", { length: 60 }).notNull().default("Teman belajar"),
  dailyTarget: integer("daily_target").notNull().default(15),
  furigana: boolean("furigana").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const attempts = pgTable("nihongo_attempts", {
  id: uuid("id").defaultRandom().primaryKey(),
  learnerId: uuid("learner_id").notNull().references(() => learners.id, { onDelete: "cascade" }),
  chapterId: integer("chapter_id").notNull(),
  kind: varchar("kind", { length: 24 }).notNull(),
  score: integer("score").notNull(),
  total: integer("total").notNull(),
  duration: integer("duration").notNull().default(0),
  answers: jsonb("answers").$type<{ questionId: string; answer: string }[]>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [index("nihongo_attempts_learner_idx").on(table.learnerId)]);

export const bookmarks = pgTable("nihongo_bookmarks", {
  learnerId: uuid("learner_id").notNull().references(() => learners.id, { onDelete: "cascade" }),
  chapterId: integer("chapter_id").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [primaryKey({ columns: [table.learnerId, table.chapterId] })]);

export const chapterProgress = pgTable("nihongo_chapter_progress", {
  learnerId: uuid("learner_id").notNull().references(() => learners.id, { onDelete: "cascade" }),
  chapterId: integer("chapter_id").notNull(),
  completedAt: timestamp("completed_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [primaryKey({ columns: [table.learnerId, table.chapterId] })]);
