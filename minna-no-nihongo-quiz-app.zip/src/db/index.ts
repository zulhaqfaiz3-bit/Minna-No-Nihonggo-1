import { drizzle, type NodePgDatabase } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import * as schema from "./schema";

export class DatabaseConfigurationError extends Error {
  readonly code = "DATABASE_NOT_CONFIGURED";

  constructor(message: string) {
    super(message);
    this.name = "DatabaseConfigurationError";
  }
}

export function getDatabaseUrl(): string {
  const connectionString = process.env.DATABASE_URL?.trim();
  if (!connectionString) {
    throw new DatabaseConfigurationError("Atur DATABASE_URL PostgreSQL pada environment variables Netlify, dengan scope Builds dan Functions.");
  }

  let url: URL;
  try { url = new URL(connectionString); }
  catch { throw new DatabaseConfigurationError("DATABASE_URL harus berupa connection string PostgreSQL yang valid."); }
  if (!["postgres:", "postgresql:"].includes(url.protocol) || !url.hostname || url.pathname.length < 2) {
    throw new DatabaseConfigurationError("DATABASE_URL harus berupa connection string PostgreSQL lengkap, termasuk nama database.");
  }

  const hostedNetlify = process.env.NETLIFY === "true" && process.env.NETLIFY_DEV !== "true" && process.env.CONTEXT !== "dev";
  if (hostedNetlify && ["localhost", "127.0.0.1", "0.0.0.0", "::1", "[::1]"].includes(url.hostname.toLowerCase())) {
    throw new DatabaseConfigurationError("Netlify tidak dapat mengakses PostgreSQL lokal. Gunakan DATABASE_URL dari database hosted seperti Neon atau Supabase.");
  }
  return connectionString;
}

type Database = NodePgDatabase<typeof schema>;
const globalForDb = globalThis as typeof globalThis & {
  __nihongoPostgresPool?: Pool;
  __nihongoDatabase?: Database;
};

export function getPool(): Pool {
  if (!globalForDb.__nihongoPostgresPool) {
    const pool = new Pool({
      connectionString: getDatabaseUrl(),
      max: 5,
      connectionTimeoutMillis: 10000,
      idleTimeoutMillis: 10000,
      maxLifetimeSeconds: 300,
      allowExitOnIdle: true,
      keepAlive: true,
    });
    // Serverless instances can be frozen between requests. An idle connection
    // error must not terminate the function or log a connection string.
    pool.on("error", (error: Error & { code?: string }) => {
      console.error("PostgreSQL idle connection error:", error.code ?? error.name);
    });
    globalForDb.__nihongoPostgresPool = pool;
  }
  return globalForDb.__nihongoPostgresPool;
}

export function getDatabase(): Database {
  if (!globalForDb.__nihongoDatabase) {
    globalForDb.__nihongoDatabase = drizzle(getPool(), { schema });
  }
  return globalForDb.__nihongoDatabase;
}

// Keep the existing `import { db } from "@/db"` API. Creating a connection is
// deferred until the first query, so next build never needs a live database.
export const db = new Proxy({} as Database, {
  get(_target, property) {
    const database = getDatabase();
    const value = Reflect.get(database, property);
    return typeof value === "function" ? value.bind(database) : value;
  },
});

export const pool = new Proxy({} as Pool, {
  get(_target, property) {
    const instance = getPool();
    const value = Reflect.get(instance, property);
    return typeof value === "function" ? value.bind(instance) : value;
  },
});
