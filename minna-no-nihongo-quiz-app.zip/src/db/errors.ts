import { DatabaseConfigurationError } from "@/db";

export function databaseFailure(error: unknown): { code: string; message: string; status: number } {
  let current = error;
  for (let depth = 0; depth < 5 && current && typeof current === "object"; depth++) {
    if (current instanceof DatabaseConfigurationError) return { code: current.code, message: current.message, status: 503 };
    const detail = current as { code?: string; cause?: unknown };
    if (detail.code === "42P01" || detail.code === "42703") {
      return { code: "DATABASE_SCHEMA_NOT_READY", message: "Database belum siap. Jalankan migrasi Drizzle atau deploy ulang dengan migrasi produksi aktif; lihat DEPLOY_NETLIFY.md.", status: 503 };
    }
    current = detail.cause;
  }
  return { code: "DATABASE_UNAVAILABLE", message: "Database belum dapat dihubungi. Periksa koneksi PostgreSQL dan environment variables Netlify, lalu coba lagi.", status: 503 };
}
