CREATE TABLE "nihongo_attempts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"learner_id" uuid NOT NULL,
	"chapter_id" integer NOT NULL,
	"kind" varchar(24) NOT NULL,
	"score" integer NOT NULL,
	"total" integer NOT NULL,
	"duration" integer DEFAULT 0 NOT NULL,
	"answers" jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "nihongo_bookmarks" (
	"learner_id" uuid NOT NULL,
	"chapter_id" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "nihongo_bookmarks_learner_id_chapter_id_pk" PRIMARY KEY("learner_id","chapter_id")
);
--> statement-breakpoint
CREATE TABLE "nihongo_chapter_progress" (
	"learner_id" uuid NOT NULL,
	"chapter_id" integer NOT NULL,
	"completed_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "nihongo_chapter_progress_learner_id_chapter_id_pk" PRIMARY KEY("learner_id","chapter_id")
);
--> statement-breakpoint
CREATE TABLE "nihongo_learners" (
	"id" uuid PRIMARY KEY NOT NULL,
	"name" varchar(60) DEFAULT 'Teman belajar' NOT NULL,
	"daily_target" integer DEFAULT 15 NOT NULL,
	"furigana" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "nihongo_attempts" ADD CONSTRAINT "nihongo_attempts_learner_id_nihongo_learners_id_fk" FOREIGN KEY ("learner_id") REFERENCES "public"."nihongo_learners"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "nihongo_bookmarks" ADD CONSTRAINT "nihongo_bookmarks_learner_id_nihongo_learners_id_fk" FOREIGN KEY ("learner_id") REFERENCES "public"."nihongo_learners"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "nihongo_chapter_progress" ADD CONSTRAINT "nihongo_chapter_progress_learner_id_nihongo_learners_id_fk" FOREIGN KEY ("learner_id") REFERENCES "public"."nihongo_learners"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "nihongo_attempts_learner_idx" ON "nihongo_attempts" USING btree ("learner_id");