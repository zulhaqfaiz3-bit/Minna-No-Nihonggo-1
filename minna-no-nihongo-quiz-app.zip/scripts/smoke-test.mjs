import { chromium, expect } from '@playwright/test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';

const base = process.env.APP_URL || 'http://127.0.0.1:3000';
const compiled = ts.transpileModule(fs.readFileSync('src/lib/learning-data.ts', 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText;
const dataModule = { exports: {} };
new Function('exports', 'module', compiled)(dataModule.exports, dataModule);
const { getQuestions } = dataModule.exports;
fs.mkdirSync('artifacts', { recursive: true });
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, ignoreHTTPSErrors: true });
const page = await context.newPage();
const errors = [];
page.on('pageerror', error => errors.push(error.message));
const update = () => page.waitForResponse(response => response.url().includes('/api/learning') && response.request().method() === 'POST');
const state = () => page.evaluate(async () => (await fetch('/api/learning')).json());

try {
  await page.goto(base, { waitUntil: 'networkidle' });
  await expect(page.getByRole('heading', { name: /Konnichiwa/ })).toBeVisible();
  const readiness = await context.request.get(`${base}/api/health`);
  assert.equal(readiness.status(), 200);
  assert.equal((await readiness.json()).database, 'ready');
  const rejectedOrigin = await context.request.post(`${base}/api/learning`, { headers: { Origin: 'https://untrusted.example.com', 'X-Forwarded-Host': 'untrusted.example.com' }, data: { action: 'settings', name: 'Tidak diizinkan', dailyTarget: 15, furigana: true } });
  assert.equal(rejectedOrigin.status(), 403);
  const learningHeaders = await page.evaluate(async () => {
    const response = await fetch('/api/learning', { cache: 'no-store' });
    return { status: response.status, cache: response.headers.get('Cache-Control'), netlifyCache: response.headers.get('Netlify-CDN-Cache-Control') };
  });
  assert.equal(learningHeaders.status, 200);
  assert.match(learningHeaders.cache, /private.*no-store/);
  assert.equal(learningHeaders.netlifyCache, 'no-store');
  console.log('Healthcheck, cross-origin protection and private no-store Netlify cache headers passed.');
  await page.evaluate(() => document.fonts.ready);
  await page.screenshot({ path: 'artifacts/dashboard-desktop.png', fullPage: false });
  console.log('Dashboard loaded. Chapter section position:', await page.locator('.chapter-section').boundingBox());

  await page.getByRole('button', { name: 'Semua Bab 25', exact: true }).click();
  await expect(page.locator('.chapter-card')).toHaveCount(25);
  await page.getByRole('searchbox', { name: 'Cari bab', exact: true }).fill('25');
  await expect(page.locator('.chapter-card')).toHaveCount(1);
  await page.locator('.chapter-open').click();
  let dialog = page.getByRole('dialog');
  await expect(dialog.getByRole('heading', { name: 'Kalau suatu hari...' })).toBeVisible();
  assert(await dialog.locator('ruby rt').count() > 0);
  await dialog.getByRole('button', { name: /Kotoba/ }).click();
  const audioResponse = page.waitForResponse(response => response.url().includes('/audio/c25-w0.mp3'));
  await dialog.getByRole('button', { name: 'Putar pelafalan Jepang', exact: true }).first().click();
  assert([200, 206].includes((await audioResponse).status()));
  let response = update();
  await dialog.getByRole('button', { name: 'Simpan bab', exact: true }).click();
  assert.equal((await response).status(), 200);
  response = update();
  await dialog.getByRole('button', { name: 'Tandai selesai', exact: true }).click();
  assert.equal((await response).status(), 200);
  await expect(dialog.getByRole('button', { name: 'Bab sudah selesai', exact: true })).toBeVisible();
  await dialog.getByRole('button', { name: 'Tutup materi', exact: true }).click();
  await page.getByRole('button', { name: /Bab Tersimpan/ }).click();
  await expect(page.locator('.chapter-card')).toHaveCount(1);
  await page.reload({ waitUntil: 'networkidle' });
  let saved = await state();
  assert(saved.completed.includes(25)); assert(saved.bookmarks.includes(25));
  console.log('Chapter search, furigana, real audio, bookmarks and persisted completion passed.');

  await page.getByRole('button', { name: 'Buka profil dan pengaturan', exact: true }).click();
  dialog = page.getByRole('dialog');
  await dialog.getByLabel('Nama panggilan').fill('Ayu');
  await dialog.getByLabel('Target latihan harian').selectOption('20');
  await dialog.getByRole('checkbox').uncheck();
  response = update();
  await dialog.getByRole('button', { name: 'Simpan pengaturan', exact: true }).click();
  assert.equal((await response).status(), 200);
  await expect(dialog).toHaveCount(0);
  await page.getByRole('button', { name: 'Ikhtisar', exact: true }).click();
  await expect(page.getByRole('heading', { name: /Konnichiwa, Ayu/ })).toBeVisible();
  await expect(page.locator('.furigana-toggle')).toHaveAttribute('aria-pressed', 'false');
  console.log('Profile, target and furigana preferences passed.');

  await page.locator('.practice-card').filter({ hasText: 'Partikel' }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Mulai latihan', exact: true }).click();
  for (const [i, question] of getQuestions(1, 'particles').entries()) {
    await page.locator('.answer-option').filter({ hasText: question.answer }).click();
    await page.getByRole('button', { name: 'Periksa jawaban', exact: true }).click();
    await expect(page.locator('.answer-feedback')).toContainText('Tepat sekali');
    if (i === 1) response = update();
    await page.getByRole('button', { name: i === 1 ? 'Lihat hasil' : 'Soal berikutnya', exact: true }).click();
  }
  assert.equal((await response).status(), 200);
  await expect(page.locator('.result-score')).toHaveText('100%');
  await expect(page.locator('.save-status')).toContainText('tersimpan otomatis');
  saved = await state();
  assert.equal(saved.attempts[0].score, 2); assert.equal(saved.attempts[0].total, 2);
  assert.equal(saved.stats.quizCount, 1); assert.equal(saved.stats.accuracy, 100); assert.equal(saved.stats.streak, 1);
  await page.getByRole('button', { name: 'Lihat pembahasan', exact: true }).click();
  await expect(page.locator('.review-item')).toHaveCount(2);
  await page.getByRole('button', { name: 'Kembali ke ruang belajar', exact: false }).click();
  console.log('Quiz grading, explanations and PostgreSQL results passed.');

  const apiPost = body => page.evaluate(async payload => {
    const response = await fetch('/api/learning', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    return { status: response.status, state: await response.json() };
  }, body);
  const invalid = await apiPost({ action: 'settings', name: 'X', dailyTarget: 2, furigana: false });
  assert.equal(invalid.status, 400);
  const questions = getQuestions(1, 'particles');
  const graded = await apiPost({ action: 'attempt', chapterId: 1, kind: 'particles', score: 999, answers: questions.map(q => ({ questionId: q.id, answer: q.options.find(option => option !== q.answer) })), duration: 3 });
  assert.equal(graded.status, 200);
  const gradedState = graded.state;
  assert.equal(gradedState.result.score, 0);
  assert.equal(gradedState.stats.accuracy, 50);
  console.log('API validation and server-side score recalculation passed.');

  await page.getByRole('button', { name: 'Listening', exact: true }).click();
  await page.getByLabel('Filter bab audio').selectOption('25');
  await expect(page.locator('.audio-example')).toHaveCount(2);
  await page.getByLabel('Kecepatan audio').selectOption('0.75');
  const sentenceAudio = page.waitForResponse(response => response.url().includes('/audio/c25-e0.mp3'));
  await page.locator('.audio-example .audio-button').first().click();
  assert([200, 206].includes((await sentenceAudio).status()));
  await page.locator('.audio-example summary').first().click();
  await expect(page.locator('.audio-example details').first()).toHaveAttribute('open', '');
  await page.getByRole('button', { name: 'Kosakata', exact: true }).click();
  await page.getByLabel('Filter bab kosakata').selectOption('0');
  await page.getByRole('searchbox', { name: 'Cari kosakata', exact: true }).fill('nihon');
  await expect(page.locator('.word-card')).toHaveCount(1);
  assert.equal(await page.locator('.word-card ruby').count(), 0);
  response = update(); await page.locator('.furigana-toggle').click(); assert.equal((await response).status(), 200);
  await expect(page.locator('.word-card ruby rt')).toHaveCount(1);
  await page.getByRole('button', { name: 'Progres Belajar', exact: true }).click();
  await expect(page.locator('.attempt-table > div')).toHaveCount(3);
  console.log('Listening, speed, translations, word search, furigana and progress page passed.');

  await page.getByRole('button', { name: 'Latihan Kuis', exact: true }).click();
  await page.locator('.builder-fields select').nth(0).selectOption('25');
  for (const kind of ['vocabulary', 'translation', 'listening', 'mixed']) {
    await page.locator('.builder-fields select').nth(1).selectOption(kind);
    await page.locator('.practice-builder').getByRole('button', { name: 'Mulai latihan', exact: true }).click();
    const chapterQuestions = getQuestions(25, kind);
    for (const [i, question] of chapterQuestions.entries()) {
      if (question.kind === 'listening') {
        await page.locator('.listening-question .audio-button').click();
        await expect(page.locator('.listening-question .audio-button')).toHaveAttribute('aria-pressed', 'true');
      }
      if (question.kind === 'vocabulary' && i === 0) {
        await page.locator('.question-japanese .audio-button').click();
        await expect(page.locator('.question-japanese .audio-button')).toHaveAttribute('aria-pressed', 'true');
      }
      await page.locator('.answer-option').filter({ hasText: question.answer }).click();
      await page.getByRole('button', { name: 'Periksa jawaban', exact: true }).click();
      await expect(page.locator('.answer-feedback')).toContainText('Tepat sekali');
      await expect(page.locator('.answer-feedback')).not.toContainText('[');
      if (question.kind !== 'particles') assert(await page.locator('.answer-feedback ruby rt').count() > 0);
      if (kind === 'translation' && i === 0) await page.screenshot({ path: 'artifacts/quiz-furigana.png', fullPage: false });
      if (i + 1 === chapterQuestions.length) response = update();
      await page.getByRole('button', { name: i + 1 === chapterQuestions.length ? 'Lihat hasil' : 'Soal berikutnya', exact: true }).click();
    }
    assert.equal((await response).status(), 200);
    await expect(page.locator('.result-score')).toHaveText('100%');
    await expect(page.locator('.save-status')).toContainText('tersimpan otomatis');
    await page.getByRole('button', { name: 'Kembali ke ruang belajar', exact: false }).click();
  }
  console.log('All quiz types in chapter 25, listening playback and furigana in explanations passed.');

  const mobile = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true, ignoreHTTPSErrors: true });
  const mobilePage = await mobile.newPage();
  mobilePage.on('pageerror', error => errors.push(error.message));
  await mobilePage.goto(base, { waitUntil: 'networkidle' });
  await mobilePage.evaluate(() => document.fonts.ready);
  await mobilePage.screenshot({ path: 'artifacts/dashboard-mobile.png', fullPage: true });
  assert(await mobilePage.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
  await mobilePage.getByRole('button', { name: 'Buka navigasi', exact: true }).click();
  await mobilePage.getByRole('button', { name: 'Semua Bab 25', exact: true }).click();
  await expect(mobilePage.locator('.chapter-card')).toHaveCount(25);
  assert(await mobilePage.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
  await mobilePage.locator('.chapter-open').first().click();
  await expect(mobilePage.getByRole('dialog')).toBeVisible();
  assert(await mobilePage.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
  await mobile.close();
  assert.deepEqual(errors, []);
  console.log('Mobile navigation, responsive layout, lesson panel and absence of runtime errors passed.');
  console.log('ALL SMOKE TESTS PASSED');
} finally {
  await context.close();
  await browser.close();
}
