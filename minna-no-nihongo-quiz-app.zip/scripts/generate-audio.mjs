import fs from 'node:fs';
import ts from 'typescript';
import { spawnSync } from 'node:child_process';

const source = fs.readFileSync('src/lib/learning-data.ts', 'utf8');
const compiled = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText;
const module = { exports: {} };
new Function('exports', 'module', compiled)(module.exports, module);
const { chapters, plainJapanese } = module.exports;
const items = chapters.flatMap((chapter) => [
  ...chapter.words.map((word, i) => ({ key: `c${chapter.id}-w${i}`, text: plainJapanese(word.jp) })),
  ...chapter.examples.map((example, i) => ({ key: `c${chapter.id}-e${i}`, text: plainJapanese(example.jp) })),
]);
const result = spawnSync('python3', ['scripts/render-audio.py'], { input: JSON.stringify(items), encoding: 'utf8', env: { ...process.env, PYTHONPATH: '/tmp/nihongo-python' }, timeout: 300000 });
console.log(result.stdout);
if (result.stderr) console.error(result.stderr);
process.exit(result.status ?? 1);
