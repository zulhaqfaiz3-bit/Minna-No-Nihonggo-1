import "dotenv/config";
import { spawnSync } from "node:child_process";
import { checkAssets } from "./check-assets.mjs";

function run(command, args) {
  const result = spawnSync(command, args, { stdio: "inherit", env: process.env, shell: process.platform === "win32" });
  if (result.error) throw new Error(`Tidak dapat menjalankan ${command}. Pastikan dependencies sudah terpasang.`);
  if (result.status !== 0) throw new Error(`Tahap ${command} gagal (exit ${result.status ?? "unknown"}). Periksa log di atas.`);
}

try {
  const hostedNetlify = process.env.NETLIFY === "true" && process.env.NETLIFY_DEV !== "true" && process.env.CONTEXT !== "dev";
  if (hostedNetlify) {
    const databaseUrl = process.env.DATABASE_URL?.trim();
    if (!databaseUrl) throw new Error("DATABASE_URL belum disetel. Tambahkan connection string PostgreSQL hosted di Netlify > Environment variables, scope Builds dan Functions, lalu deploy ulang. Lihat DEPLOY_NETLIFY.md.");
    let url;
    try { url = new URL(databaseUrl); } catch { throw new Error("DATABASE_URL tidak valid. Salin connection string lengkap dari provider PostgreSQL."); }
    if (!["postgres:", "postgresql:"].includes(url.protocol) || !url.hostname || url.pathname.length < 2) throw new Error("DATABASE_URL harus menggunakan PostgreSQL dan mencantumkan nama database.");
    if (["localhost", "127.0.0.1", "0.0.0.0", "::1", "[::1]"].includes(url.hostname.toLowerCase())) throw new Error("DATABASE_URL masih menunjuk ke PostgreSQL lokal. Netlify memerlukan database hosted seperti Neon atau Supabase, bukan database sandbox.");
    console.log("Konfigurasi PostgreSQL hosted ditemukan. Connection string tidak dicetak ke log.");
  }

  console.log("Memeriksa materi dan audio:", checkAssets());
  if (!process.argv.includes("--check-only")) {
    const migrationSetting = process.env.RUN_DATABASE_MIGRATIONS?.trim().toLowerCase();
    if (migrationSetting && !["true", "false"].includes(migrationSetting)) throw new Error("RUN_DATABASE_MIGRATIONS harus bernilai true atau false.");
    const shouldMigrate = migrationSetting === "true" || (hostedNetlify && process.env.CONTEXT === "production" && migrationSetting !== "false");
    if (shouldMigrate) {
      console.log("Menerapkan migrasi database produksi melalui Drizzle...");
      run("npm", ["exec", "--", "tsx", "scripts/migrate-db.ts"]);
    } else {
      console.log("Migrasi tidak dijalankan untuk konteks ini. Gunakan database preview terpisah sebelum mengaktifkan RUN_DATABASE_MIGRATIONS=true.");
    }
    run("npm", ["exec", "--", "next", "typegen"]);
    run("npm", ["exec", "--", "tsc", "--noEmit", "--pretty", "false"]);
    run("npm", ["run", "build"]);
    console.log("Build Next.js selesai. Netlify akan memaketkan API menggunakan adapter OpenNext otomatis.");
  }
} catch (error) {
  console.error(`Build Netlify dihentikan: ${error.message}`);
  process.exitCode = 1;
}
