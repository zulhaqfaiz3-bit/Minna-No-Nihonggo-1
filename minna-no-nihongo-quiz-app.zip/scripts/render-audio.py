import asyncio
import json
import os
import sys
import edge_tts

items = json.load(sys.stdin)
os.makedirs('public/audio', exist_ok=True)
semaphore = asyncio.Semaphore(4)

async def render(item):
    path = f"public/audio/{item['key']}.mp3"
    if os.path.exists(path) and os.path.getsize(path) > 1000:
        return True
    async with semaphore:
        for attempt in range(3):
            try:
                speech = edge_tts.Communicate(item['text'], 'ja-JP-NanamiNeural', rate='-10%')
                await speech.save(path + '.part')
                os.replace(path + '.part', path)
                print(f"Generated {item['key']}", flush=True)
                return True
            except Exception as error:
                if attempt == 2:
                    print(f"Failed {item['key']}: {error}", file=sys.stderr)
                    return False
                await asyncio.sleep(1 + attempt)

async def main():
    results = await asyncio.gather(*(render(item) for item in items))
    print(f"Audio ready: {sum(results)}/{len(results)}", flush=True)
    if not all(results):
        sys.exit(1)

asyncio.run(main())
