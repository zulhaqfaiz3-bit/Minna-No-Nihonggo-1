import "dotenv/config";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { spawnSync } from "node:child_process";
import { NextRequest } from "next/server";
import { sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import { DatabaseConfigurationError, db, getDatabaseUrl, getPool } from "@/db";
import { databaseFailure } from "@/db/errors";
import { learners } from "@/db/schema";
import { isAllowedOrigin } from "@/lib/request-origin";

const savedEnvironment = { ...process.env };
function withEnvironment(values: Record<string, string | undefined>, action: () => void) {
  const previous = Object.fromEntries(Object.keys(values).map((key) => [key, process.env[key]]));
  for (const [key, value] of Object.entries(values)) { if (value === undefined) delete process.env[key]; else process.env[key] = value; }
  try { action(); }
  finally { for (const [key, value] of Object.entries(previous)) { if (value === undefined) delete process.env[key]; else process.env[key] = value; } }
}

function preflight(extra: Record<string, string>) {
  return spawnSync(process.execPath, ["scripts/netlify-build.mjs", "--check-only"], {
    encoding: "utf8", timeout: 30000,
    env: { ...savedEnvironment, NETLIFY: "true", NETLIFY_DEV: "false", CONTEXT: "production", ...extra },
  });
}

async function main() {
  withEnvironment({ DATABASE_URL: "" }, () => {
    assert.throws(() => getDatabaseUrl(), DatabaseConfigurationError);
    assert.throws(() => db.select(), DatabaseConfigurationError);
  });
  withEnvironment({ NETLIFY: "true", NETLIFY_DEV: "false", CONTEXT: "production" }, () => {
    for (const host of ["localhost", "127.0.0.1", "[::1]"]) {
      withEnvironment({ DATABASE_URL: `postgresql://${host}/nihongo` }, () => assert.throws(() => getDatabaseUrl(), /hosted/));
    }
  });
  withEnvironment({ DATABASE_URL: "postgresql://database.example.org/nihongo?sslmode=require", NETLIFY: "true" }, () => assert.match(getDatabaseUrl(), /sslmode=require/));
  assert.equal(databaseFailure(new DatabaseConfigurationError("Konfigurasi belum siap")).status, 503);
  assert.equal(databaseFailure(new Error("Query failed", { cause: { code: "42P01" } })).code, "DATABASE_SCHEMA_NOT_READY");
  console.log("PASS: database lazy, validasi URL hosted, dan pesan error tanpa kredensial.");

  withEnvironment({ NETLIFY: "true", APP_ORIGIN: "https://nihongo.example.com", URL: "https://nihongo.netlify.app", DEPLOY_URL: "https://deploy-id--nihongo.netlify.app", DEPLOY_PRIME_URL: "https://deploy-preview-1--nihongo.netlify.app" }, () => {
    const request = (origin?: string, extra: Record<string, string> = {}) => new NextRequest("https://function.internal/api/learning", { headers: { ...(origin ? { origin } : {}), ...extra } });
    for (const origin of ["https://nihongo.example.com", "https://nihongo.netlify.app", "https://deploy-id--nihongo.netlify.app", "https://deploy-preview-1--nihongo.netlify.app"]) assert.equal(isAllowedOrigin(request(origin)), true);
    for (const origin of ["https://evil.example", "https://another-project.netlify.app", "null", "not-a-url", "https://user:pass@nihongo.example.com"]) assert.equal(isAllowedOrigin(request(origin)), false);
    assert.equal(isAllowedOrigin(request("https://evil.example", { "x-forwarded-host": "evil.example" })), false);
    assert.equal(isAllowedOrigin(request(undefined, { "sec-fetch-site": "cross-site" })), false);
    assert.equal(isAllowedOrigin(request()), true);
  });
  console.log("PASS: origin produksi, custom domain, preview; origin asing dan forged forwarded host ditolak.");

  const missing = preflight({ DATABASE_URL: "", DATABASE_URL_UNPOOLED: "" });
  assert.equal(missing.status, 1); assert.match(missing.stderr, /DATABASE_URL belum disetel/);
  const local = preflight({ DATABASE_URL: "postgresql://127.0.0.1/nihongo", DATABASE_URL_UNPOOLED: "" });
  assert.equal(local.status, 1); assert.match(local.stderr, /lokal/);
  const valid = preflight({ DATABASE_URL: "postgresql://database.example.org/nihongo?sslmode=require", DATABASE_URL_UNPOOLED: "" });
  assert.equal(valid.status, 0, valid.stderr); assert.match(valid.stdout, /audioFiles: 175/);
  console.log("PASS: preflight Netlify menolak konfigurasi salah dan memeriksa seluruh 175 audio.");

  const sourceUrl = new URL(getDatabaseUrl());
  if (!["localhost", "127.0.0.1", "[::1]"].includes(sourceUrl.hostname)) {
    console.log("SKIP: pengujian migrasi terisolasi hanya dijalankan pada PostgreSQL lokal, bukan database produksi.");
    return;
  }
  const name = `nihongo_netlify_test_${randomUUID().replace(/-/g, "").slice(0, 12)}`;
  sourceUrl.pathname = `/${name}`;
  let created = false;
  let testPool: Pool | undefined;
  try {
    await db.execute(sql.raw(`CREATE DATABASE "${name}"`));
    created = true;
    const migrationEnvironment = { ...savedEnvironment, DATABASE_URL: sourceUrl.toString(), DATABASE_URL_UNPOOLED: "", NETLIFY: "false", CONTEXT: "dev" };
    for (let run = 0; run < 2; run++) {
      const migrated = spawnSync("npm", ["exec", "--", "tsx", "scripts/migrate-db.ts"], { encoding: "utf8", env: migrationEnvironment, timeout: 60000 });
      assert.equal(migrated.status, 0, migrated.stderr);
      assert.match(migrated.stdout, /Migrasi Drizzle selesai/);
    }
    testPool = new Pool({ connectionString: sourceUrl.toString(), max: 1 });
    const testDb = drizzle(testPool);
    const tables = await testDb.execute(sql`SELECT count(*)::int AS count FROM information_schema.tables WHERE table_schema = 'public' AND table_name LIKE 'nihongo_%'`);
    assert.equal(tables.rows[0].count, 4);
    const migrations = await testDb.execute(sql`SELECT count(*)::int AS count FROM nihongo_migrations.__drizzle_migrations`);
    assert.equal(migrations.rows[0].count, 1);
    const learnerId = randomUUID();
    await testDb.insert(learners).values({ id: learnerId, name: "Tes deploy" });
    const profile = await testDb.select().from(learners);
    assert.equal(profile[0].name, "Tes deploy");
    assert.equal(profile[0].furigana, true);
    console.log("PASS: migrasi database kosong, migrasi ulang idempotent, empat tabel, dan penyimpanan profil.");
  } finally {
    if (testPool) await testPool.end();
    if (created) await db.execute(sql.raw(`DROP DATABASE "${name}"`));
    await getPool().end();
  }
  console.log("ALL NETLIFY DEPLOYMENT TESTS PASSED");
}

main().catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : "Pengujian deploy gagal.");
  process.exitCode = 1;
});
