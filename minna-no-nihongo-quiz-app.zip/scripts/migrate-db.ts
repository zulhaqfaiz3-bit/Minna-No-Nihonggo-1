import "dotenv/config";
import path from "node:path";
import { sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/node-postgres";
import { migrate } from "drizzle-orm/node-postgres/migrator";
import { DatabaseConfigurationError, getPool } from "@/db";

async function main() {
  // Runtime uses a pooled URL; migration can use a direct URL when supplied.
  const directUrl = process.env.DATABASE_URL_UNPOOLED?.trim();
  if (directUrl) process.env.DATABASE_URL = directUrl;
  const pool = getPool();
  let client;
  let locked = false;
  try {
    client = await pool.connect();
    const migrationDb = drizzle(client);
    // Serialize overlapping deploys. All lock and migration queries run on
    // the same checked-out connection; no session lock is left in the pool.
    await migrationDb.execute(sql`SELECT pg_advisory_lock(723419025)`);
    locked = true;
    await migrate(migrationDb, {
      migrationsFolder: path.join(process.cwd(), "drizzle"),
      migrationsSchema: "nihongo_migrations",
      migrationsTable: "__drizzle_migrations",
    });
    console.log("Migrasi Drizzle selesai. Migrasi yang telah diterapkan tidak diulang.");
  } finally {
    if (client) {
      try {
        if (locked) await drizzle(client).execute(sql`SELECT pg_advisory_unlock(723419025)`);
      } finally { client.release(); }
    }
    await pool.end();
  }
}

main().catch((error: unknown) => {
  if (error instanceof DatabaseConfigurationError) console.error(error.message);
  else {
    const cause = error instanceof Error ? (error as Error & { cause?: { code?: string }; code?: string }) : undefined;
    const code = cause?.cause?.code ?? cause?.code ?? "UNKNOWN";
    console.error(`Migrasi PostgreSQL gagal (${code}). Periksa connection string, SSL, dan izin database. Untuk produksi baru, gunakan database kosong; lihat DEPLOY_NETLIFY.md.`);
  }
  process.exitCode = 1;
});
