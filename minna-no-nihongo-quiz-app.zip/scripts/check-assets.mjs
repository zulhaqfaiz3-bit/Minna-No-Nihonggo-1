import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import ts from "typescript";

export function checkAssets() {
  const compiled = ts.transpileModule(fs.readFileSync("src/lib/learning-data.ts", "utf8"), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
  }).outputText;
  const dataModule = { exports: {} };
  new Function("exports", "module", compiled)(dataModule.exports, dataModule);
  const { chapters, getQuestions, TOTAL_QUESTIONS } = dataModule.exports;
  const missing = [];
  let audioCount = 0;
  let questionCount = 0;

  const verifyFile = (relativePath) => {
    if (!fs.existsSync(relativePath) || fs.statSync(relativePath).size < 500) missing.push(relativePath);
  };
  verifyFile("public/images/japan-hero.png");
  for (const chapter of chapters) {
    chapter.words.forEach((_, index) => { verifyFile(`public/audio/c${chapter.id}-w${index}.mp3`); audioCount++; });
    chapter.examples.forEach((_, index) => { verifyFile(`public/audio/c${chapter.id}-e${index}.mp3`); audioCount++; });
    for (const kind of ["particles", "vocabulary", "translation", "listening"]) {
      const questions = getQuestions(chapter.id, kind);
      questionCount += questions.length;
      for (const question of questions) {
        if (question.options.length !== 4 || !question.options.includes(question.answer) || new Set(question.options).size !== 4) {
          throw new Error(`Pilihan jawaban tidak valid: ${question.id}`);
        }
      }
    }
  }
  if (missing.length) throw new Error(`Aset belum lengkap. Pastikan folder public ikut di-push ke Git: ${missing.join(", ")}`);
  if (questionCount !== TOTAL_QUESTIONS) throw new Error("Jumlah bank soal tidak konsisten.");
  return { chapters: chapters.length, questions: questionCount, audioFiles: audioCount };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try { console.log("Aset deploy lengkap:", checkAssets()); }
  catch (error) { console.error(error.message); process.exitCode = 1; }
}
